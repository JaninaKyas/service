<?php
  if (isset($_POST)) {
    $data    = file_get_contents("php://input");
    $infos   = json_decode($data, true);
	  
	require_once __DIR__ . "/model/tariff_queries.php";
	require_once __DIR__ . "/views/rates/forms/rate_card.php";
	
	$tariffQueries = new TariffQueries();
	$rateInfos     = $tariffQueries->getRateById($infos["rateId"]);
	
	$rateCard      = new RateCard($rateInfos[0]);
	
	$content["rateDiv"]  = $rateCard->getRateCard(false);
	$content["parentId"] = "conRateInfos";
	
	echo json_encode($content);
  }
?>