<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

  if (isset($_POST)) {
    $data    = file_get_contents("php://input");
    $infos   = json_decode($data, true);
	  
	// model
	require_once __DIR__ . "/model/address_queries.php";  // address
	require_once __DIR__ . "/model/location_queries.php"; // location
	require_once __DIR__ . "/model/debator_queries.php";  // sepa
	require_once __DIR__ . "/model/bank_queries.php";     // bank
	require_once __DIR__ . "/model/country_queries.php";  // country
	require_once __DIR__ . "/model/customer_queries.php"; // customer

    require_once __DIR__ . "/views/confirm/create_pdf.php";
	require_once __DIR__ . "/views/confirm/mail_send.php";
    require_once __DIR__ . "/views/confirm/confirm.php";

    $addressQueries  = new AddressQueries();
	$locationQueries = new LocationQueries();
	$debatorQueries  = new DebatorQueries();
	$bankQueries     = new BankQueries();
	$countryQueries  = new CountryQueries();
	$customerQueries = new CustomerQueries();
	$createPdf       = new CreatePdf($infos);
	$mailSend        = new MailSend($infos);
	$confirm         = new Confirm();
	  
    // postal address
    $postAddressId  = -1;
    $postLocationId = -1;
    $hpaId          = -1;
    $hplId          = -1;	
    if (array_key_exists("postalAddress", $infos)) {
	  if ( array_key_exists("street"  , $infos["postalAddress"])
		&& array_key_exists("hNr"     , $infos["postalAddress"])
	    && array_key_exists("zipcode" , $infos["postalAddress"])
		&& array_key_exists("place"   , $infos["postalAddress"])
		&& array_key_exists("district", $infos["postalAddress"])) {
		$hpaId = $addressQueries->getIdByAddressData(
		  $infos["postalAddress"]["street"],
          $infos["postalAddress"]["hNr"],
          $infos["postalAddress"]["zipcode"],
          $infos["postalAddress"]["place"],
          $infos["postalAddress"]["district"]		  
		);
		
		if (empty($hpaId)) {
		  $hplId = $locationQueries->getIdByLocationData(
		    $infos["postalAddress"]["place"],
            $infos["postalAddress"]["district"]
		  );
		  
		  if (empty($hplId)) {
			$postLocationId = $locationQueries->saveLocationData(
			  $infos["postalAddress"]["place"],
              $infos["postalAddress"]["district"]
			);  
		  } else {
			$postLocationId = $hplId[0]["id"];
		  }
		  
		  $postAddressId = $addressQueries->saveNewAddress(
		    $infos["postalAddress"]["street"],
            $infos["postalAddress"]["hNr"],
            $infos["postalAddress"]["zipcode"],
			$postLocationId
		  );
		} else {
		  $postAddressId = $hpaId[0]["id"];
		}
	  }
	}

    // technology address
	$techAddressId  = $postAddressId;
	$techLocationId = $postLocationId;
	$htaId          = -1;
	$htlId          = -1;
	if (array_key_exists("techAddress", $infos)) {
	  if ( array_key_exists("street"       , $infos["techAddress"])
		&& array_key_exists("hnr"          , $infos["techAddress"])
	    && array_key_exists("zipcode"      , $infos["techAddress"])
		&& array_key_exists("place"        , $infos["techAddress"])
		&& array_key_exists("district"     , $infos["techAddress"])
		&& array_key_exists("isDiffAddress", $infos["techAddress"])) {
		if ($infos["techAddress"]["isDiffAddress"] != "" || $infos["techAddress"]["isDiffAddress"] != false) {
		  $htaId = $addressQueries->getIdByAddressData(
		    $infos["techAddress"]["street"],
            $infos["techAddress"]["hnr"],
            $infos["techAddress"]["zipcode"],
            $infos["techAddress"]["place"],
            $infos["techAddress"]["district"]		  
		  );
		  
		  if (empty($htaId)) {
			$htlId = $locationQueries->getIdByLocationData(
		      $infos["techAddress"]["place"],
              $infos["techAddress"]["district"]
		    );
			
			if (empty($htlId)) {
			  $techLocationId = $locationQueries->saveLocationData(
			    $infos["techAddress"]["place"],
                $infos["techAddress"]["district"]
			  ); 
			} else {
			  $techLocationId = $htlId[0]["id"];
			}
			
			$techAddressId = $addressQueries->saveNewAddress(
		      $infos["techAddress"]["street"],
              $infos["techAddress"]["hnr"],
              $infos["techAddress"]["zipcode"],
			  $techLocationId
		    );
		  } else {
			$techAddressId = $htaId[0]["id"];
		  }
		}
	  }
	}

    // customer
	$customerId = -1;
	$hcId       = -1;
	$customerNr =  1;
	$hcn        = -1;
	if (array_key_exists("customer", $infos)) {
	  if ( array_key_exists("salut", $infos["customer"])
	    && array_key_exists("fName", $infos["customer"])
		&& array_key_exists("lName", $infos["customer"])
	    && array_key_exists("phone", $infos["customer"])
		&& array_key_exists("mobil", $infos["customer"])
		&& array_key_exists("mail" , $infos["customer"])) {
	    $hcn = $customerQueries->getLastId();
		
		if (empty($hcn)) {
		  $customerNr = 1;
		} else {
		  $customerNr = $hcn[0]["id"];
		}
		
		$company = '';
		if (array_key_exists("company", $infos["customer"])) {
		  $company = $infos["customer"]["company"];
		}
		
		$birthDay = '1000-01-01';
		if (array_key_exists("birthDay", $infos["customer"])) {
		  $birthDay = $infos["customer"]["birthDay"];
		}
		
		$hcId = $customerQueries->getIdByCustomerData(
		  $infos["customer"]["fName"],
		  $infos["customer"]["lName"],
		  $infos["customer"]["phone"],
		  $infos["customer"]["mobil"],
		  $infos["customer"]["mail"]
		);
		
		if (empty($hcId)) {
		  $customerId = $customerQueries->saveCustomerData(
            $customerNr,
			$infos["customer"]["salut"],
			$infos["customer"]["fName"],
			$infos["customer"]["lName"],
			$company,
			$birthDay,
			$infos["customer"]["phone"],
		    $infos["customer"]["mobil"],
		    $infos["customer"]["mail"]
	      );
		} else {
		  $customerId = $hcId[0]["id"];
		}
	  }
	}

	// sepa data
	$debatorId         = -1;
	$debatorAddressId  = $postAddressId;
	$debatorLocationId = $postLocationId;
	$debatorBankId     = -1;
	$countryId         = -1;
	$hdId              = -1;
	$hdaId             = -1;
	$hdlId             = -1;
	$hdbId             = -1;
	$hcId              = -1;
	if (array_key_exists("sepaData", $infos)) {
	  if ( array_key_exists("name"    , $infos["sepaData"])
		&& array_key_exists("street"  , $infos["sepaData"])
	    && array_key_exists("hnr"     , $infos["sepaData"])
		&& array_key_exists("zipcode" , $infos["sepaData"])
		&& array_key_exists("place"   , $infos["sepaData"])
		&& array_key_exists("district", $infos["sepaData"])
		&& array_key_exists("country" , $infos["sepaData"])
		&& array_key_exists("iban"    , $infos["sepaData"])
		&& array_key_exists("bic"     , $infos["sepaData"])) {		
		$hdId = $debatorQueries->getIdByDebatorData(
		  $infos["sepaData"]["name"],
		  $infos["sepaData"]["street"],
		  $infos["sepaData"]["hnr"],
		  $infos["sepaData"]["zipcode"],
		  $infos["sepaData"]["place"],
		  $infos["sepaData"]["district"],
		  $infos["sepaData"]["country"],
		  $infos["sepaData"]["iban"],
		  $infos["sepaData"]["bic"]
		);
		
		if (empty($hdId)) {

		  // get bank id or create new entry and then get bank id
		  $hdbId = $bankQueries->getIdByBankData('', $infos["sepaData"]["bic"]);
		
		  if (empty($hdbId)) {
		    $debatorBankId = $bankQueries->saveNewBank('', $infos["sepaData"]["bic"]);
		  } else {
		    $debatorBankId = $hdbId[0]["id"];
		  }

          // get country id or create new entry and then get country id		
		  $hcId = $countryQueries->getIdByCountryData($infos["sepaData"]["country"]);
		
		  if (empty($hcId)) {
		    $countryId = $countryQueries->saveNewCountry($infos["sepaData"]["country"], '');
		  } else {
		    $countryId = $hcId[0]["id"];
		  }
		
		  // get address id or create new entry and then get address id
		  $hdaId = $addressQueries->getIdByAddressData(
		    $infos["sepaData"]["street"],
            $infos["sepaData"]["hnr"],
            $infos["sepaData"]["zipcode"],
            $infos["sepaData"]["place"],
            $infos["sepaData"]["district"]		  
		  );
		
		  if (empty($hdaId)) {
			// get location id or create new entry and then get location id
		    $hdlId = $locationQueries->getIdByLocationData(
		      $infos["sepaData"]["place"],
              $infos["sepaData"]["district"]
		    );
		  
		    if (empty($hdlId)) {
		      $debatorLocationId = $postLocationId->saveLocationData(
			    $infos["sepaData"]["place"],
                $infos["sepaData"]["district"]
			  );
		    } else {
		      $debatorLocationId = $hdlId[0]["id"];
		    }
		  
		    $debatorAddressId = $addressQueries->saveNewAddress(
		      $infos["sepaData"]["street"],
              $infos["sepaData"]["hnr"],
              $infos["sepaData"]["zipcode"],
			  $debatorLocationId
		    );
		  } else {
		    $debatorAddressId = $hdaId[0]["id"];
		  }
		  
		  $debatorId = $debatorQueries->saveNewDebator(
		    $debatorAddressId,
			$countryId,
			$debatorBankId,
			$infos["sepaData"]["name"],
			$infos["sepaData"]["iban"]
		  );

		} else {
		  $debatorId = $hdId[0]["id"];
		}
	  }
	}

	$html        =      "";
	$save        =    true;
	$attachments = array("filePaths" => array(), "fileNames" => array());
	if ($infos["choosenPath"] == 4 || $infos["choosenSubPath"] == 2) {
	  if ( array_key_exists("conKind"       , $infos)
		&& array_key_exists("selTech"       , $infos)
	    && array_key_exists("recall"        , $infos)
		&& array_key_exists("isWish"        , $infos["recall"])
		&& array_key_exists("termin"        , $infos["recall"])
		&& array_key_exists("conRequestRate", $infos)
		&& array_key_exists("techCare"      , $infos)
		&& array_key_exists("porting"       , $infos)
		&& array_key_exists("phone"         , $infos)
		&& array_key_exists("careTermin1"   , $infos)
		&& array_key_exists("message"       , $infos)) {
		require_once __DIR__ . "/model/customer_connection_requests_queries.php";
        $customerConRequestQueries = new CustomerConnectionRequestsQueries();
		$save = $customerConRequestQueries->saveRequest(
	      $customerId,
		  $postAddressId,
		  $infos["techCare"],
		  $infos["conKind"],
		  $infos["selTech"],
		  $infos["conRequestRate"],
		  $infos["recall"]["isWish"],
		  $infos["recall"]["termin"],
		  $infos["phone"],
		  $infos["porting"],
		  $infos["careTermin1"],
		  $infos["message"]
	    );
	  }
	  
	  if ($save) {
		if ($mailSend->sendMail()) {
		  $html = $confirm->buildConfirmRequest();
		}
	  }
	} else if ($infos["choosenPath"] == 1 || $infos["choosenSubPath"] == 1) {		
	  require_once __DIR__ . "/model/house_owner_queries.php";
	  require_once __DIR__ . "/model/customer_ftth_request_queries.php";
	  
	  $ftthRequestQueries = new CustomerFttHRequestQueries();
	  $houseOwnerQueries  = new HouseOwnerQueries();
	  
	  // house owner
	  $houseOwnerId          = -1;
	  $houseOwnerAddressId   = $postAddressId;
	  $fHouseOwnerAddressId  = $postAddressId;
	  $houseOwnerLocationId  = $postLocationId;
	  $fHouseOwnerLocationId = $postLocationId;
	  $hhoId                 = -1;
	  $hoaId                 = -1;
	  $hfhoaId               = -1;
	  $hholId                = -1;
	  $hfholId               = -1;
	  if (array_key_exists("hoData", $infos)) {
		if ( array_key_exists("title"     , $infos["hoData"])
		  && array_key_exists("fName"     , $infos["hoData"])
	      && array_key_exists("lName"     , $infos["hoData"])
		  && array_key_exists("company"   , $infos["hoData"])
		  && array_key_exists("street"    , $infos["hoData"])
		  && array_key_exists("hnr"       , $infos["hoData"])
		  && array_key_exists("zipcode"   , $infos["hoData"])
		  && array_key_exists("place"     , $infos["hoData"])
		  && array_key_exists("district"  , $infos["hoData"])
		  && array_key_exists("hrNumber"  , $infos["hoData"])
		  && array_key_exists("phone"     , $infos["hoData"])
		  && array_key_exists("mobil"     , $infos["hoData"])
		  && array_key_exists("mail"      , $infos["hoData"])
		  && array_key_exists("fFloor"    , $infos["hoData"])
		  && array_key_exists("fFloorKind", $infos["hoData"])
		  && array_key_exists("fDFloor"   , $infos["hoData"])
		  && array_key_exists("fStreet"   , $infos["hoData"])
		  && array_key_exists("fHNr"      , $infos["hoData"])
		  && array_key_exists("fZipcode"  , $infos["hoData"])
		  && array_key_exists("fPlace"    , $infos["hoData"])
		  && array_key_exists("fDistrict" , $infos["hoData"])) {
		  $hhoId = $houseOwnerQueries->getIdByHouseOwnerData(
		    $infos["hoData"]["fName"],
			$infos["hoData"]["lName"],
			$infos["hoData"]["company"],
			$infos["hoData"]["street"],
			$infos["hoData"]["hnr"],
			$infos["hoData"]["zipcode"],
			$infos["hoData"]["place"],
			$infos["hoData"]["district"],
			$infos["hoData"]["hrNumber"],
			$infos["hoData"]["mail"],
			$infos["hoData"]["phone"],
			$infos["hoData"]["mobil"],
			$infos["hoData"]["fStreet"],
			$infos["hoData"]["fHNr"],
			$infos["hoData"]["fZipcode"],
			$infos["hoData"]["fPlace"],
			$infos["hoData"]["fDistrict"]
          );
		  
          if (empty($hhoId)) {
			$hoaId = $addressQueries->getIdByAddressData(
		      $infos["hoData"]["street"],
			  $infos["hoData"]["hnr"],
			  $infos["hoData"]["zipcode"],
			  $infos["hoData"]["place"],
			  $infos["hoData"]["district"]		  
		    );
			
			$hfhoaId = $addressQueries->getIdByAddressData(
		      $infos["hoData"]["fStreet"],
			  $infos["hoData"]["fHNr"],
			  $infos["hoData"]["fZipcode"],
			  $infos["hoData"]["fPlace"],
			  $infos["hoData"]["fDistrict"]		  
		    );
			
			if (empty($hoaId)) {
			  $hholId = $locationQueries->getIdByLocationData(
		        $infos["hoData"]["place"],
			    $infos["hoData"]["district"]
		      );
			  
			  if (empty($hholId)) {
				$houseOwnerLocationId = $locationQueries->saveLocationData(
			      $infos["hoData"]["place"],
			      $infos["hoData"]["district"]
			    );
			  } else {
				$houseOwnerLocationId = $hholId[0]["id"];
			  }
			  
			  $houseOwnerAddressId = $addressQueries->saveNewAddress(
		        $infos["hoData"]["street"],
			    $infos["hoData"]["hnr"],
			    $infos["hoData"]["zipcode"],
			    $houseOwnerLocationId
		      );
			} else {
			  $houseOwnerAddressId = $hoaId[0]["id"];
			}
			
			if (empty($hfhoaId)) {
			  $hfholId = $locationQueries->getIdByLocationData(
		        $infos["hoData"]["fPlace"],
			    $infos["hoData"]["fDistrict"]
		      );
			  
			  if (empty($hfholId)) {
				$fHouseOwnerLocationId = $locationQueries->saveLocationData(
			      $infos["hoData"]["fPlace"],
			      $infos["hoData"]["fDistrict"]
			    );
			  } else {
				$fHouseOwnerLocationId = $hfholId[0]["id"];
			  }
			  
			  $fHouseOwnerAddressId = $addressQueries->saveNewAddress(
		        $infos["hoData"]["fStreet"],
			    $infos["hoData"]["fHNr"],
			    $infos["hoData"]["fZipcode"],
			    $fHouseOwnerLocationId
		      );
			} else {
			  $fHouseOwnerAddressId = $hfhoaId[0]["id"];
			}

            $houseOwnerId = $houseOwnerQueries->saveNewHouseOwner(
			  $infos["hoData"]["title"],
			  $infos["hoData"]["fName"],
			  $infos["hoData"]["lName"],
			  $infos["hoData"]["company"],
			  $houseOwnerAddressId,
			  $fHouseOwnerAddressId,
			  $infos["hoData"]["hrNumber"],
			  $infos["hoData"]["fFloor"],
			  $infos["hoData"]["fFloorKind"],
			  $infos["hoData"]["fDFloor"],
			  $infos["hoData"]["mail"],
			  $infos["hoData"]["phone"],
			  $infos["hoData"]["mobil"]
	        );
		  } else {
			$houseOwnerId = $hhoId[0]["id"];
		  }
		}
		
		if ( array_key_exists("conKind"       , $infos)
		  && array_key_exists("selTech"       , $infos)
	      && array_key_exists("conPointTyp"   , $infos)
		  && array_key_exists("kindConPoint"  , $infos["conPointTyp"])
		  && array_key_exists("cntUnits"      , $infos["conPointTyp"])
		  && array_key_exists("completionDate", $infos["conPointTyp"])
		  && array_key_exists("introHouse"    , $infos)
		  && array_key_exists("ihTyp"         , $infos["introHouse"])
		  && array_key_exists("else"          , $infos["introHouse"])
		  && array_key_exists("rate"          , $infos)
		  && array_key_exists("mainNum"       , $infos["sepaData"])
		  && array_key_exists("subNum"        , $infos["sepaData"])) {
		  $save = $ftthRequestQueries->saveFttHRequestData(
		    $customerId,
			$postAddressId,
			$techAddressId,
			$debatorId,
			$infos["conKind"],
			$infos["selTech"],
			$infos["rate"],
            $houseOwnerId,
			$infos["introHouse"]["ihTyp"],
			$infos["conPointTyp"]["kindConPoint"],
			$infos["sepaData"]["mainNum"],
			$infos["sepaData"]["subNum"],
			$infos["conPointTyp"]["cntUnits"],
			$infos["conPointTyp"]["completionDate"],
			$infos["introHouse"]["else"]
	      );
		}
	  }
	  
	  if ($save > 0) {
		$createPdf->createPdf($customerId, 'sepa_lastschriftmandat', 1);
		$createPdf->createPdf($customerId, 'GEE', 3);
		  
		$attachments = array(
		  "filePaths" => array(
		    __DIR__ . '/views/confirm/pdfs/sepa_lastschriftmandat_' . $customerId . '.pdf',
			__DIR__ . '/views/confirm/pdfs/GEE_'                    . $customerId . '.pdf',
		  ),
	      "fileNames" => array(
			'sepa_lastschriftmandat_' . $customerId . '.pdf',
			'GEE_'                    . $customerId . '.pdf'
		  )
		);
		  
		if ($mailSend->sendMail(2, $attachments)) {
		  $html = $confirm->buildConfirmFttH();
		}
	  }
	} else if ($infos["choosenPath"] == 2) {
	  require_once __DIR__ . "/model/contract_queries.php";
	  require_once __DIR__ . "/model/hardware_queries.php";
	  require_once __DIR__ . "/model/contract_x_hardware_queries.php";
	  require_once __DIR__ . "/model/dataholder_queries.php";
	  require_once __DIR__ . "/model/telecommunication_system_queries.php";
	  require_once __DIR__ . "/model/phone_numbers_queries.php";
	  require_once __DIR__ . "/model/provider_change_order_queries.php";
	  require_once __DIR__ . "/model/contract_x_tariff_option_queries.php";
	  
	  $contractQueries   = new ContractQueries();
	  $hardwareQueries   = new HardwareQueries();
	  $dataholderQueries = new DataholderQueries();
	  $conXHwQueries     = new ContractXHardwareQueries();
	  $teleSysQueries    = new TelecommunicationSystemQueries();
	  $phoneNrQueries    = new PhoneNumberQueries();
	  $pcoQueries        = new ProviderChangeOrderQueries();
	  $cxtoQueries       = new ContractXTariffOptionQueries();
	  
	  // contract
	  $contractId = -1;
	  $hconId     = -1;
	  if ( array_key_exists("conKind"    , $infos)
	    && array_key_exists("rateId"     , $infos)
		&& array_key_exists("wishTermin" , $infos)
		&& array_key_exists("duration"   , $infos)
		&& array_key_exists("invoicePost", $infos)
		&& array_key_exists("tae"        , $infos["techAddress"])) {
		$hconId = $contractQueries->getIdByContractData(
		  $customerId,
		  $postAddressId,
		  $techAddressId,
	      $infos["rateId"],
		  $infos["duration"],
	      $debatorId,
		  $infos["wishTermin"],
		  $infos["techAddress"]["tae"]
	    );
		
		if (empty($hconId)) {
		  $contractId = $contractQueries->saveContract(
		    $customerId,
		    $postAddressId,
		    $techAddressId,
	        $infos["rateId"],
		    $infos["duration"],
	        $debatorId,
		    $infos["wishTermin"],
			$infos["invoicePost"],
			$infos["techAddress"]["tae"]
	      );
		} else {
		  $contractId = $hconId[0]["id"];
		}
	  }
	  
	  if (array_key_exists("options", $infos)) {
		// hardware
		$hardwareId1 = -1;
		$hhardId1    = -1;
		$hardwareId2 = -1;
		$hhardId2    = -1;
		if (array_key_exists("hardware", $infos["options"])) {
		  if (array_key_exists("hw-2", $infos["options"]["hardware"])) {
			$hhardId1 = $hardwareQueries->getHardwareById($infos["options"]["hardware"]["hw-2"]);
			$hardwareId1 = $hhardId1[0]["id"];
			$conXHwQueries->saveDataholder($contractId, $hardwareId1);
		  }
		  
		  if (array_key_exists("hw-3", $infos["options"]["hardware"])) {
			$hhardId2 = $hardwareQueries->getHardwareById($infos["options"]["hardware"]["hw-3"]);
			$hardwareId2 = $hhardId2[0]["id"];
			$conXHwQueries->saveDataholder($contractId, $hardwareId2);
		  }
		}
		  
		// porting phone numbers
		$providerChangeOrderId = -1;
		$hpcoId                = -1;
		$isWishPorting         = false;
		if (array_key_exists("portingPhoneData", $infos["options"])) {
		  // dataholder
		  $dataholderId         = -1;
		  $dataholderAddressId  = $postAddressId;
		  $dataholderLocationId = $postLocationId;
		  $hdataaId             = -1;
		  $hdatalId             = -1;
		  if (array_key_exists("dataHolder", $infos["options"]["portingPhoneData"])) {
			if ( array_key_exists("fName"  , $infos["options"]["portingPhoneData"]["dataHolder"])
			  && array_key_exists("lName"  , $infos["options"]["portingPhoneData"]["dataHolder"])
		      && array_key_exists("street" , $infos["options"]["portingPhoneData"]["dataHolder"])
			  && array_key_exists("hnr"    , $infos["options"]["portingPhoneData"]["dataHolder"])
			  && array_key_exists("zipcode", $infos["options"]["portingPhoneData"]["dataHolder"])
			  && array_key_exists("place"  , $infos["options"]["portingPhoneData"]["dataHolder"])) {
			  $hdataaId = $addressQueries->getIdByAddressData(
		        $infos["options"]["portingPhoneData"]["dataHolder"]["street"],
                $infos["options"]["portingPhoneData"]["dataHolder"]["hnr"],
                $infos["options"]["portingPhoneData"]["dataHolder"]["zipcode"],
                $infos["options"]["portingPhoneData"]["dataHolder"]["place"],
                ''		  
		      );
			  
			  if (empty($hdataaId)) {
				$hdatalId = $locationQueries->getIdByLocationData($infos["options"]["portingPhoneData"]["dataHolder"]["place"], '');
				
				if (empty($hdatalId)) {
				  $dataholderLocationId = $locationQueries->saveLocationData($infos["postalAddress"]["place"], '');

                  $dataholderAddressId = $addressQueries->saveNewAddress(
		            $infos["options"]["portingPhoneData"]["dataHolder"]["street"],
                    $infos["options"]["portingPhoneData"]["dataHolder"]["hnr"],
                    $infos["options"]["portingPhoneData"]["dataHolder"]["zipcode"],
			        $dataholderAddressId
		           );
				} else {
				  $dataholderLocationId = $hdatalId[0]["id"];
				}
			  } else {
				$dataholderAddressId = $hdataaId[0]["id"];
			  }
			  
			  $dataholderId = $dataholderQueries->saveDataholder(
			    $dataholderAddressId,
				$infos["options"]["portingPhoneData"]["dataHolder"]["fName"],
				$infos["options"]["portingPhoneData"]["dataHolder"]["lName"]
			  );
			}
		  }
		
		  // to porting phone numbers
		  $phoneNrId = -1;
		  $hpNrId    = -1;
		  if (array_key_exists("phoneNr", $infos["options"]["portingPhoneData"])) {
			if ( array_key_exists("onkz", $infos["options"]["portingPhoneData"]["phoneNr"])
			  && array_key_exists("phone1", $infos["options"]["portingPhoneData"]["phoneNr"])
		      && array_key_exists("phone2", $infos["options"]["portingPhoneData"]["phoneNr"])
			  && array_key_exists("phone3", $infos["options"]["portingPhoneData"]["phoneNr"])
			  && array_key_exists("phone4", $infos["options"]["portingPhoneData"]["phoneNr"])
			  && array_key_exists("phone5", $infos["options"]["portingPhoneData"]["phoneNr"])
			  && array_key_exists("phone6", $infos["options"]["portingPhoneData"]["phoneNr"])
			  && array_key_exists("phone7", $infos["options"]["portingPhoneData"]["phoneNr"])
			  && array_key_exists("phone8", $infos["options"]["portingPhoneData"]["phoneNr"])
			  && array_key_exists("phone9", $infos["options"]["portingPhoneData"]["phoneNr"])) {
			  $hpNrId = $phoneNrQueries->getIdByPhoneNumberData(
			    $infos["options"]["portingPhoneData"]["phoneNr"]["onkz"],
				$infos["options"]["portingPhoneData"]["phoneNr"]["phone1"],
				$infos["options"]["portingPhoneData"]["phoneNr"]["phone2"],
				$infos["options"]["portingPhoneData"]["phoneNr"]["phone3"],
				$infos["options"]["portingPhoneData"]["phoneNr"]["phone4"],
				$infos["options"]["portingPhoneData"]["phoneNr"]["phone5"],
				$infos["options"]["portingPhoneData"]["phoneNr"]["phone6"],
				$infos["options"]["portingPhoneData"]["phoneNr"]["phone7"],
				$infos["options"]["portingPhoneData"]["phoneNr"]["phone8"],
				$infos["options"]["portingPhoneData"]["phoneNr"]["phone9"]
			  );
			  
			  if (empty($hpNrId)) {
				$phoneNrId = $phoneNrQueries->savePhoneNumber(
				  $infos["options"]["portingPhoneData"]["phoneNr"]["onkz"],
				  $infos["options"]["portingPhoneData"]["phoneNr"]["phone1"],
				  $infos["options"]["portingPhoneData"]["phoneNr"]["phone2"],
				  $infos["options"]["portingPhoneData"]["phoneNr"]["phone3"],
				  $infos["options"]["portingPhoneData"]["phoneNr"]["phone4"],
				  $infos["options"]["portingPhoneData"]["phoneNr"]["phone5"],
				  $infos["options"]["portingPhoneData"]["phoneNr"]["phone6"],
				  $infos["options"]["portingPhoneData"]["phoneNr"]["phone7"],
				  $infos["options"]["portingPhoneData"]["phoneNr"]["phone8"],
				  $infos["options"]["portingPhoneData"]["phoneNr"]["phone9"]
				);
			  } else {
				$phoneNrId = $hpNrId[0]["id"];
			  }
			}
		  }
		
		  // telecommunication systems
		  $tkSystemId = -1;
		  $htksId     = -1;
		  if (array_key_exists("tkSystems", $infos["options"]["portingPhoneData"])) {
			if ( array_key_exists("directNr"   , $infos["options"]["portingPhoneData"]["tkSystems"])
			  && array_key_exists("queryPoint" , $infos["options"]["portingPhoneData"]["tkSystems"])
		      && array_key_exists("rnBlockFrom", $infos["options"]["portingPhoneData"]["tkSystems"])
			  && array_key_exists("rnBlockTo"  , $infos["options"]["portingPhoneData"]["tkSystems"])) {
			  $tkSystemId = $teleSysQueries->getIdByTelecommunicationSystemData(
			    $infos["options"]["portingPhoneData"]["tkSystems"]["directNr"],
				$infos["options"]["portingPhoneData"]["tkSystems"]["queryPoint"],
				$infos["options"]["portingPhoneData"]["tkSystems"]["rnBlockFrom"],
				$infos["options"]["portingPhoneData"]["tkSystems"]["rnBlockTo"]
			  );
			  
			  if (empty($tkSystemId)) {
				$tkSystemId = $teleSysQueries->saveTelecommunicationSystem(
				  $infos["options"]["portingPhoneData"]["tkSystems"]["directNr"],
				  $infos["options"]["portingPhoneData"]["tkSystems"]["queryPoint"],
				  $infos["options"]["portingPhoneData"]["tkSystems"]["rnBlockFrom"],
				  $infos["options"]["portingPhoneData"]["tkSystems"]["rnBlockTo"]
				);
			  } else {
				$tkSystemId = $tkSystemId[0]["id"];
			  }
			}
		  }
		
		  // save in parent table
		  if (array_key_exists("curProvider", $infos["options"]["portingPhoneData"])) {
			$hpcoId = $pcoQueries->getIdByProviderChangeOrderData(
			  $dataholderId,
			  $phoneNrId,
			  $tkSystemId,
			  $infos["options"]["portingPhoneData"]["curProvider"]
	        );
			
			if (empty($hpcoId)) {
			  $providerChangeOrderId = $pcoQueries->saveProviderChangeOrder(
			    $dataholderId,
			    $phoneNrId,
			    $tkSystemId,
			    $infos["options"]["portingPhoneData"]["curProvider"]
	          );
			} else {
			  $providerChangeOrderId = $hpcoId[0]["id"];
			}
		  }
		}
		  
		$cntAddSipId = -1;                                                                               
		if (array_key_exists("cntAddSIP", $infos["options"]) && $infos["options"]["cntAddSIP"] > 0) {
		  $cntAddSipId = 5;
		}
		
		$cntAllnetId = -1;
		if (array_key_exists("cntAllnet", $infos["options"]) && $infos["options"]["cntAllnet"] > 0) {
		  $cntAllnetId = 6;
		}
		
		if ( array_key_exists("ipAddress"       , $infos["options"])
		  && array_key_exists("phoneDefault"    , $infos["options"])
		  && array_key_exists("portingPhoneData", $infos["options"])
		  && array_key_exists("porting"         , $infos["options"]["portingPhoneData"])
		  && array_key_exists("lineFee"         , $infos["options"])
		  && array_key_exists("deployPrice"     , $infos["options"])
		  && array_key_exists("serviceComfort"  , $infos["options"])
		  && array_key_exists("tvOption"        , $infos["options"])) {
		  if ($infos["options"]["ipAddress"] > 0) {
			$cxtoQueries->saveContractXTariffOption($contractId, $infos["options"]["ipAddress"]);
		  }
		  
		  if ($infos["options"]["phoneDefault"] > 0) {
			$cxtoQueries->saveContractXTariffOption($contractId, $infos["options"]["phoneDefault"]);
		  }
		  
		  if ($infos["options"]["portingPhoneData"]["porting"] > 0) {
			$cxtoQueries->saveContractXTariffOption($contractId, $infos["options"]["portingPhoneData"]["porting"]);
		  }
		  
		  if ($infos["options"]["lineFee"] > 0) {
			$cxtoQueries->saveContractXTariffOption($contractId, $infos["options"]["lineFee"]);
		  }
		  
		  if ($infos["options"]["deployPrice"] > 0) {
			$cxtoQueries->saveContractXTariffOption($contractId, $infos["options"]["deployPrice"]);
		  }
		  
		  if ($infos["options"]["serviceComfort"] > 0) {
			$cxtoQueries->saveContractXTariffOption($contractId, $infos["options"]["serviceComfort"]);
		  }
		  
		  if ($infos["options"]["tvOption"] > 0) {
			$cxtoQueries->saveContractXTariffOption($contractId, $infos["options"]["tvOption"]);
		  }
		  
		  if ($cntAddSipId > 0) {
			$cxtoQueries->saveContractXTariffOption($contractId, $cntAddSipId, $infos["options"]["cntAddSIP"]);
		  }
		  
		  if ($cntAllnetId > 0) {
			$cxtoQueries->saveContractXTariffOption($contractId, $cntAllnetId, $infos["options"]["cntAllnet"]);
		  }
		}
	  }
	  
	  // confirmation contract
	  $hIndex = 0;	
	  if ($contractId > 0) {
		$createPdf->createPdf($customerId, 'sepa_lastschriftmandat', 1);
		$hIndex = 0;
		  
		$attachments["filePaths"][0] = __DIR__ . '/views/confirm/pdfs/sepa_lastschriftmandat_' . $customerId . '.pdf';
		$attachments["fileNames"][0] = 'sepa_lastschriftmandat_' . $customerId . '.pdf';
		  
		if ( array_key_exists("options", $infos)
		  && array_key_exists("portingPhoneData", $infos["options"])
		  && !empty($infos["options"]["portingPhoneData"])) {
		  $createPdf->createPdf($customerId, 'anbieterwechselauftrag', 2);
		  $hIndex = 1;
			
		  $attachments["filePaths"][1] = __DIR__ . '/views/confirm/pdfs/anbieterwechselauftrag_' . $customerId . '.pdf';
		  $attachments["fileNames"][1] = 'anbieterwechselauftrag_' . $customerId . '.pdf';
		}
		 
		if (array_key_exists("mailTemp", $infos) && $infos["mailTemp"] != "") {
		  $createPdf->createPdf($customerId, 'bestaetigung_vertrag', 4);
		  $hIndex += 1;
			
		  $attachments["filePaths"][$hIndex] = __DIR__ . '/views/confirm/pdfs/bestaetigung_vertrag_' . $customerId . '.pdf';
		  $attachments["fileNames"][$hIndex] = 'bestaetigung_vertrag_' . $customerId . '.pdf';
		}
		  
		if ($mailSend->sendMail(3, $attachments)) {
		  $html = $confirm->buildConfirmPK();
		}
	  }
	}
	
	// delete pdf files
	if (!empty($attachments) && array_key_exists("fileNames", $attachments)) {
	  for ($i = 0; $i < count($attachments["fileNames"]); $i++) {
	    unlink($attachments["filePaths"][$i]);
	  }
	}
	  
	$content = array(
	  "step8content" => $html
	);
	  
	echo json_encode($content);
  }
?>