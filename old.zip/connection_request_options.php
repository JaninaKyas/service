<?php
  if (isset($_POST)) {
    $data    = file_get_contents("php://input");
    $infos   = json_decode($data, true);
	  
	require_once __DIR__ . "/model/technology_queries.php";
    require_once __DIR__ . "/views/connectionRequest/connection_request_care.php";
	  
	$techQueries = new TechnologyQueries();
	$techKinds   = $techQueries->getAllTechKinds();
	  
	$connectionRequestCare = new ConnectionRequestCare($techKinds);
	
	$isToUseAddTemplate = false;
	if (array_key_exists("subPath", $infos) && $infos["subPath"] == 2) {
	  $isToUseAddTemplate = true;
	}
	  
	$content = array(
	  "step6content" => $connectionRequestCare->buildConnectionRequestOptionsTemplate($isToUseAddTemplate)
	);

	echo json_encode($content);
  } 
?>