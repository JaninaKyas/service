<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

  if (isset($_POST)) {
    $data    = file_get_contents("php://input");
    $infos   = json_decode($data, true);
	  
	$defaultValues = array();

	$address = $infos["postalAddress"];
	  
	if ($infos["techAddress"]["street"] != "") {
	  $address["street"]   = $infos["techAddress"]["street"];
	  $address["hNr"]      = $infos["techAddress"]["hnr"];
	  $address["zipcode"]  = $infos["techAddress"]["zipcode"];
	  $address["place"]    = $infos["techAddress"]["place"];
	  $address["district"] = $infos["techAddress"]["district"];
	}
	  
	require_once __DIR__ . "/model/connection_point_types_queries.php";
	require_once __DIR__ . "/model/house_intro_types_queries.php";
	require_once __DIR__ . "/views/glassFibre/glass_fibre.php";
	require_once __DIR__ . "/views/glassFibre/forms/connection_data.php";

	$conPointTypeQueries   = new ConPointTypeQueries();
	$houseIntroTypeQueries = new HouseIntroTypeQueries();
	  
	$defaultValues["cptData"] = $conPointTypeQueries->getAllConPointTypes();
	$defaultValues["hitData"] = $houseIntroTypeQueries->getAllHouseIntroTypes();
	  
	$gfConnectionDataTemplate = new GlassFibre(array());
	$gfPropertyTemplate       = new ConnectionData(array(), array());
	  
	$content = array(
	  "step4content" => $gfConnectionDataTemplate->getGlasFibreConnectionTemplate($defaultValues),
	  "step5content" => $gfPropertyTemplate->buildSeveralHomeownersConsent($address, $infos["customer"])
	);

	echo json_encode($content);
  } 
?>