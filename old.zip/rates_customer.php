<?php
  if (isset($_POST)) {
    $data  = file_get_contents("php://input");
    $infos = json_decode($data, true);

	if (array_key_exists("customer", $infos) && array_key_exists("psTae", $infos["customer"])) {
	  $infos["postalAddress"]["psTae"] = $infos["customer"]["psTae"];
	}
	
	$caDiffAddress = 'none';
	if (array_key_exists("techAddress", $infos) && array_key_exists("isDiffAddress", $infos["techAddress"]) && $infos["techAddress"]["isDiffAddress"]) {
	  $caDiffAddress = 'block';
	}
	  
	require __DIR__ . "/views/rates/tariff.php";
	$tariffFormHtml  = new Tariff(array(), $infos["postalAddress"], $infos["techAddress"], $infos["customer"]);

	$content = array(
	  "step3Lable"    => "Kundendaten",
	  "step3"         => $tariffFormHtml->getCustomerTemplate(),
	  "caDiffAddress" => $caDiffAddress  
    );
	  
	echo json_encode($content);
  } 
?>