<?php
  if (isset($_POST)) {
    $data    = file_get_contents("php://input");
    $infos   = json_decode($data, true);
	$content = array();
	  
	require_once __DIR__ . "/views/connectionRequest/connection_request.php";
	$conRequest = new ConnectionRequest(array(), array());
	  
	$content = array(
	  "step3Lable"   => "Rückruf",
	  "step3"        => $conRequest->getRecallTemplate(),
	  "step4content" => $conRequest->getRecallTemplate()
	);

	echo json_encode($content);
  } 
?>