<?php
  ini_set('display_errors', 1);
  ini_set('display_startup_errors', 1);
  error_reporting(E_ALL);

  $dir = str_replace("/views/confirm", "", __DIR__);

  require_once $dir . "/plugins/PDF/dompdf/autoload.inc.php";

  use Dompdf\Dompdf;
  use Dompdf\Options;

  class CreatePdf {
	private $path     = __DIR__ . '/pdfs';
	private $fileName = '';
	private $data     = array();
	
	public function __construct ($newData) {
	  $this->data = $newData;
		
	  var_dump($this->data); exit;
	}
	
	public function createPdf($id, $name, $typ) {
	  $this->fileName = $this->path . '/' . $name . '_' . $id . '.pdf';
	
	  $html = '<html>
		  <body style="font-family: Calibri;">';
	  $html .= $this->buildMainContent($typ);	
	  $html .= '</body></html>';
		
	  $dompdf  = new Dompdf();
	  $dompdf->loadHtml($html);
	  $dompdf->setPaper('A4', 'portrait');
	  $dompdf->set_option('isRemoteEnabled', true);
	  $dompdf->render();
	  $pdfFile = $dompdf->output();
	  file_put_contents($this->fileName, $pdfFile);
	}
	  
	private function buildMainContent($typ): string {		
	  $returnValue = $this->buildHeader($typ);
		
	  switch ($typ) {
		case 1:
		  // SEPA
		  $returnValue .= '
		    <table style="width: 100%;">
		      <tr>
			    <td>
				  <strong>SEPA-Basis Lastschriftmandat / SEPA Direct Debit Mandate</strong> <br>
				  Project66 IT Service & Design / Brehna.net <br>
				  Max-Planck-Str. 2, 06796 Brehna <br><br>
				<td>
			  </tr>
			  
			  <tr>
			    <td>
				  <strong>Gläubiger-Identifikationsnummer / creditor identifier</strong> <br>
				  DE68ZZZ00002002280 <br><br><br><br>
				</td>
			  </tr>
			  
			  <tr>
			    <td>
				  Project66 IT Service & Design / Brehna.net <br>
				  Max-Planck-Str. 2 <br>
				  06796 Brehna <br><br><br>
				</td>
			  </tr>
			</table>
			
			<table style="width: 100%;">
			  <tr>
			    <td style="padding: 0 5px;">
				  Zahlungspflichtiger <br>
				  <input type="text" style="width: 100%; height: 20px;" value="' . $this->data["sepaData"]["name"] . '">
				</td>
			  </tr>
			</table>
			
			<table style="width: 100%;">
			  <tr>
			    <td>
				  Zahlungspflichtige Strasse <br>
				  <input type="text" style="width: 100%; height: 20px;" value="' . $this->data["sepaData"]["street"] . '">
				</td>
				
				<td style="padding: 0 5px;">
				  Zahlungspflichtige Hausnummer <br>
				  <input type="text" style="width: 100%; height: 20px;" value="' . $this->data["sepaData"]["hnr"] . '">
				</td>
			  </tr>

              <tr>
			    <td>
				  Zahlungspflichtige PLZ <br>
				  <input type="text" style="width: 100%; height: 20px;" value="' . $this->data["sepaData"]["zipcode"] . '">
				</td>
				
				<td style="padding: 0 5px;">
				  Zahlungspflichtiger Ort <br>
				  <input type="text" style="width: 100%; height: 20px;" value="' . $this->data["sepaData"]["place"] . '">
				</td>
			  </tr>
			</table>
			
			<table style="width: 100%;">
			  <tr>
			    <td colspan="2" style="padding: 0 5px;">
				  Zahlungspflichtige Land <br>
				  <input type="text" style="width: 100%; height: 20px;" value="' . $this->data["sepaData"]["country"] . '">
				</td>
			  </tr>
			</table>
			
			<table style="width: 100%;">
			  <tr>
			    <td>
				  Zahlungspflichtige IBAN <br>
				  <input type="text" style="width: 100%; height: 20px;" value="' . $this->data["sepaData"]["iban"] . '">
				</td>
				
				<td style="padding: 0 5px;">
				  Zahlungspflichtiger SWIFT BIC <br>
				  <input type="text" style="width: 100%; height: 20px;" value="' . $this->data["sepaData"]["bic"] . '">
				</td>
			  </tr>
		    </table>
			
			<br><br>
			
			<table style="width: 100%;">
			  <tr>
			    <td colspan="2">
				  Ich ermächtige (Wir ermächtigen) Project66 IT-Service & 
                  Design/Brehna.net, Zahlungen von meinem (unseren) Konto 
                  mittels Lastschrift einzuziehen. Zugleich weise ich mein 
                  (weisen wir unser) Kreditinstitut an, die von Project66 auf 
                  mein (unsere) Konto gezogenen Lastschriften einzulösen
				  <br><br>
				</td>
			  </tr>
			  
			  <tr>
			    <td style="width: 100px;">
				  <strong>Hinweise:</strong>
				  <br><br><br><br><br>
				</td>
				
				<td>
				  Ich kann/Wir können innerhalb von acht Wochen 
                  beginnend mit dem Belastungsdatum, die Erstattung des 
                  belasteten Betrags verlangen. Es gelten dabei die mit 
                  meinem/unserem Kreditinstitut vereinbarten Bedingungen.
				  <br><br>
				  <strong>
				    Bitte lassen Sie sich den Eingang des SEPA-Mandates von
					Ihrer Bank bestätigen.
				  </strong>
				</td>
			  </tr>
			</table>
			
			<br><br><br>
			
			<table style="width: 100%;">
			  <tr>
			    <td>
				  <input type="text" style="width: 100px; border: none; border-bottom: 1px solid black;">
				  <br>
				  <span style="font-size: 10px;">Ort, Datum</span>
				</td>
				
				<td>
				  <input type="text" style="width: 200px; border: none; border-bottom: 1px solid black;">
				  <br>
				  <span style="font-size: 10px;">Unterschrift</span>
				</td>
				
				<td></td>
			  </tr>
			</table><br><br>';
			$returnValue .= $this->buildFooter();
		  break;
		case 2:
		  // Anbieterwechselauftrag  
		  $returnValue .= '
		    <table style="width: 100%; margin-top: 5px;">
			  <tr>
			    <td>
				  <input type="checkbox" style="transform: scale(1.5); margin-top: -20px;" checked>
				</td>
				<td>
				  <b>
				    Kündigung von Anschlüssen beim Endkundenvertragspartner abgebend (EKPabg)
				  </b>
				  <br>
				  <span style="font-size: 10px;">
				    (separate Kündigung beim bisherigen Anbieter nicht erforderlich) <br>
                    Hiermit kündige/n ich/wir den zu unten gemachten Angaben gehörenden Anschluss bei:
					<br>
					zum nächst möglichen Termin.
				  </span>
				</td>
				<td>
				  <input type="text" style="width: 80%; border: none; border-bottom: 1px solid black;" value="' . $this->data["options"]["portingPhoneData"]["curProvider"] . '"></td>
			  </tr>
			  
			  <tr>
			    <td>
				  <input type="checkbox" style="transform: scale(1.5); margin-top: 0px;" checked>
				</td>
				
				<td colspan="2">
				  <b>
				    Hiermit beauftrage/n ich/wir die Portierung (Mitnahme) der angegebenen Rufnummer/n.
				  </b>
				</td>
			  </tr>
			  
			  <tr>
			    <td colspan="3" style="font-size: 10px;">
				  <table style="width: 100%;">
				    <tr>
					  <td width="50px">
					    Name/Firma:
					  </td>
					  
					  <td>
					    <input type="text" style="width: 80%; border: none; border-bottom: 1px solid black; height: 15px;" value="' . $this->data["options"]["portingPhoneData"]["dataHolder"]["lName"] . '">
					  </td>
					    
					  <td width="50px">
					    Vorname:
					  </td>
					  
					  <td>
					    <input type="text" style="width: 80%; border: none; border-bottom: 1px solid black; height: 15px;" value="' . $this->data["options"]["portingPhoneData"]["dataHolder"]["fName"] . '">
					  </td>
					</tr>
					
					<tr>
					  <td width="50px">
					    Straße:
					  </td>
					  
					  <td>
					    <input type="text" style="width: 80%; border: none; border-bottom: 1px solid black; height: 15px;" value="' . $this->data["options"]["portingPhoneData"]["dataHolder"]["street"] . '">
					  </td>
					  
					  <td width="50px">
					    Hausnr.:
					  </td>
					  
					  <td>
					    <input type="text" style="width: 80%; border: none; border-bottom: 1px solid black; height: 15px;" value="' . $this->data["options"]["portingPhoneData"]["dataHolder"]["hnr"] . '">
					  </td>
					</tr>
					
					<tr>
					  <td width="50px">
					    PLZ:
					  </td>
					  
					  <td>
					    <input type="text" style="width: 80%; border: none; border-bottom: 1px solid black; height: 15px;" value="' . $this->data["options"]["portingPhoneData"]["dataHolder"]["zipcode"] . '">
					  </td>
					  
					  <td>
					    Ort:
					  </td>
					  
					  <td>
					    <input type="text" style="width: 80%; border: none; border-bottom: 1px solid black; height: 15px;" value="' . $this->data["options"]["portingPhoneData"]["dataHolder"]["place"] . '">
					  </td>
					</tr>
				  </table>
				</td>
			  </tr>
			  
			  <tr>
			    <td>
				  <input type="checkbox" style="transform: scale(1.5); margin-top: 0px;" checked>
				</td>
				
				<td>
				  <b>
				    alle Nr. der
					Anschlüsse
					portieren
				  </b>
				</td>
			  </tr>
			  
			  <tr>
			    <td colspan="3" style="font-size: 10px;">
				  <table style="width: 100%;">
				    <tr>
					  <td><b>Ortsnetzkennzahl</b></td>
					  <td colspan="3"><b>Rufnummern <span style="font-size: 8px;">(Achtung, es muss mindestens eine Rufnummer angegeben werden!)</span></b></td>
					</tr>
					
					<tr>
					  <td>
					    <input type="text" style="width: 80%; border: none; border-bottom: 1px solid black; height: 15px;" value="' . $this->data["options"]["portingPhoneData"]["phoneNr"]["onkz"] . '">
						<br><br>
						<br><br>
						<br>
					  </td>
					  
					  <td>
					    <input type="text" style="width: 80%; border: none; border-bottom: 1px solid black; height: 15px;" value="' . $this->data["options"]["portingPhoneData"]["phoneNr"]["phone1"] . '">
					    <br>
						<input type="text" style="width: 80%; border: none; border-bottom: 1px solid black; height: 15px;" value="' . $this->data["options"]["portingPhoneData"]["phoneNr"]["phone2"] . '">
						<br>
						<input type="text" style="width: 80%; border: none; border-bottom: 1px solid black; height: 15px;" value="' . $this->data["options"]["portingPhoneData"]["phoneNr"]["phone3"] . '">
					  </td>
					  
					  <td>
					    <input type="text" style="width: 80%; border: none; border-bottom: 1px solid black; height: 15px;" value="' . $this->data["options"]["portingPhoneData"]["phoneNr"]["phone4"] . '">
					    <br>
						<input type="text" style="width: 80%; border: none; border-bottom: 1px solid black; height: 15px;" value="' . $this->data["options"]["portingPhoneData"]["phoneNr"]["phone5"] . '">
						<br>
						<input type="text" style="width: 80%; border: none; border-bottom: 1px solid black; height: 15px;" value="' . $this->data["options"]["portingPhoneData"]["phoneNr"]["phone6"] . '">
					  </td>
					  
					  <td>
					    <input type="text" style="width: 80%; border: none; border-bottom: 1px solid black; height: 15px;" value="' . $this->data["options"]["portingPhoneData"]["phoneNr"]["phone7"] . '">
					    <br>
						<input type="text" style="width: 80%; border: none; border-bottom: 1px solid black; height: 15px;" value="' . $this->data["options"]["portingPhoneData"]["phoneNr"]["phone8"] . '">
						<br>
						<input type="text" style="width: 80%; border: none; border-bottom: 1px solid black; height: 15px;" value="' . $this->data["options"]["portingPhoneData"]["phoneNr"]["phone9"] . '">
					  </td>
					</tr>
				  </table>
				  
				  <table style="width: 100%;">
					<tr style="border: 1px solid blue;">
					  <td>
					    <b>
						   Telekommunikations- <br>
						   anlagen:
						</b>
					  </td>
					  
					  <td>
					    <b>Durchwahl-RN</b>
					  </td>
					  
					  <td>-</td>
					  
					  <td>
					    <b>Abfragestelle</b>
					  </td>
					  
					  <td colspan="2">
					    <b>Rufnummernblock</b>
					  </td>
					</tr>
					
					<tr>
					  <td width="25px"></td>
					  
					  <td width="125px">
					    <input type="text" style="width: 80%; border: none; border-bottom: 1px solid black; height: 15px;" value="' . $this->data["options"]["portingPhoneData"]["tkSystems"]["directNr"] . '">
					  </td>
					  
					  <td>-</td>
					  
					  <td width="125px">
					    <input type="text" style="width: 80%; border: none; border-bottom: 1px solid black; height: 15px;" value="' . $this->data["options"]["portingPhoneData"]["tkSystems"]["queryPoint"] . '">
					  </td>
					  
					  <td style="padding-top: 10px;">
					    von <input type="text" style="width: 80%; border: none; border-bottom: 1px solid black; height: 15px;" value="' . $this->data["options"]["portingPhoneData"]["tkSystems"]["rnBlockFrom"] . '">
					  </td>
					  
					  <td style="padding-top: 10px;">
					    bis <input type="text" style="width: 80%; border: none; border-bottom: 1px solid black; height: 15px;" value="' . $this->data["options"]["portingPhoneData"]["tkSystems"]["rnBlockTo"] . '">
					  </td>
					</tr>
				  </table>
				</td>
			  </tr>
			</table>
			<br>
			<table style="width: 100%;">
			  <tr>
			    <td width="100px">
				  <b>Ort, Datum:</b>
				</td>
				
				<td>
				  <input type="text" style="width: 80%; border: none; border-bottom: 1px solid black; height: 15px;">
				</td>
				
				<td width="55px">
				  <b>Unterschrift:</b>
				</td>
				
				<td>
				  <input type="text" style="width: 80%; border: none; border-bottom: 1px solid black; height: 15px;">
				</td>
			  </tr>
			</table>
			<br>
			<br>
		    <img src="' . 
			  $this->getBase64Code("https://neu.brehna.net/auftrag/views/confirm/anbieterwechsel2.JPG")
		 . '" width="700" height="500">';

		  break;
		case 3:
		  // Gundstückseigentümererklärung
		  $returnValue .= '
		    <table style="width: 100%;">
			  <tr>
			    <td>
				  Der / des / vertreten durch <br><br>
				  Eigentümer / Eigentümerin          Verwaltung <br>
				</td>
			  </tr>
			</table>
			
			<table style="width: 100%;">
			  <tr>
			    <td style="padding: 0 5px;">
				  Titel <br>
				  <input type="text" style="width: 100%; height: 20px;" value="' . $this->data["hoData"]["title"] . '">
				</td>
				
				<td>
				  Vorname <br>
				  <input type="text" style="width: 100%; height: 20px;" value="' . $this->data["hoData"]["fName"] . '">
				</td>
				
				<td style="padding: 0 5px;">
				  Nachname <br>
				  <input type="text" style="width: 100%; height: 20px;" value="' . $this->data["hoData"]["lName"] . '">
				</td>
			  </tr>
			</table>
			
			<table style="width: 100%;">
			  <tr>
			    <td style="padding: 0 5px;">
				  Firma <br>
				  <input type="text" style="width: 100%; height: 20px;" value="' . $this->data["hoData"]["company"] . '">
				</td>
			  </tr>
			</table>
			
			<table style="width: 100%;">
              <tr>
			    <td style="padding: 0 5px;">
				  Strasse <br>
				  <input type="text" style="width: 100%; height: 20px;" value="' . $this->data["hoData"]["street"] . '">
				</td>
				
				<td style="padding: 0 4px 0 0;">
				  Hausnummer <br>
				  <input type="text" style="width: 100%; height: 20px;" value="' . $this->data["hoData"]["fHNr"] . '">
				</td>
			  </tr>
			  
              <tr>
			    <td style="padding: 0 5px;">
				  PLZ <br>
				  <input type="text" style="width: 100%; height: 20px;" value="' . $this->data["hoData"]["zipcode"] . '">
				</td>
				
				<td style="padding: 0 4px 0 0;">
				  Ort <br>
				  <input type="text" style="width: 100%; height: 20px;" value="' . $this->data["hoData"]["place"] . '">
				</td>
			  </tr>
			  
              <tr>
			    <td colspan="2" style="padding: 0 5px;">
				  PLZ <br>
				  <input type="text" style="width: 100%; height: 20px;" value="' . $this->data["hoData"]["district"] . '">
				</td>
			  </tr>			  
			</table>
			
			<table style="width: 100%;">
			  <tr>
			    <td style="padding: 0 5px;">
				  HR-Nummer (falls vorhanden) <br>
				  <input type="text" style="width: 100%; height: 20px;" value="' . $this->data["hoData"]["hrNumber"] . '">
				</td>
			  </tr>
			</table>
			
			<table style="width: 100%;">
			  <tr>
			    <td align="right">
				  Nachfolgend <strong>Eigentümer / Eigentümerin,</strong>
				</td>
			  </tr>
			  
			  <tr>
			    <td>
				  gegenüber der <br><br>
				  Brehna.net <br>
				  Max-Planck-Straße 2 <br>
				  06796 Brehna
				</td>
			  </tr>
			  
			  <tr>
			    <td align="right">
				  Nachfolgend <strong>Netzbetreiber genannt</strong>
				</td>
			  </tr>
			</table>
			
			<table style="width: 100%;">
			  <tr>
			    <td>
				  <br>
				  Der Eigentümer/die Eigentümerin ist damit einverstanden, dass der Netzbetreiber auf seinem/ihrem 
                  Grundstück <br>
				</td>
			  </tr>
			</table>
			
			<table style="width: 100%;">
			  <tr>
			    <td style="padding: 0 5px;">
				  Flur <br>
				  <input type="text" style="width: 100%; height: 20px;" value="' . $this->data["hoData"]["fFloor"] . '">
				</td>
				
				<td>
				  Flurstück <br>
				  <input type="text" style="width: 100%; height: 20px;" value="' . $this->data["hoData"]["fFloorKind"] . '">
				</td>
				
				<td style="padding: 0 5px;">
				  Gemarkung <br>
				  <input type="text" style="width: 100%; height: 20px;" value="' . $this->data["hoData"]["fDFloor"] . '">
				</td>
			  </tr>
			</table>
			
			<table style="width: 100%;">
              <tr>
			    <td style="padding: 0 5px;">
				  Strasse <br>
				  <input type="text" style="width: 100%; height: 20px;" value="' . $this->data["hoData"]["fStreet"] . '">
				</td>
				
				<td style="padding: 0 4px 0 0;">
				  Hausnummer <br>
				  <input type="text" style="width: 100%; height: 20px;" value="' . $this->data["hoData"]["hnr"] . '">
				</td>
			  </tr>
			  
              <tr>
			    <td style="padding: 0 5px;">
				  PLZ <br>
				  <input type="text" style="width: 100%; height: 20px;" value="' . $this->data["hoData"]["fZipcode"] . '">
				</td>
				
				<td style="padding: 0 4px 0 0;">
				  Ort <br>
				  <input type="text" style="width: 100%; height: 20px;" value="' . $this->data["hoData"]["fPlace"] . '">
				</td>
			  </tr>
			  
              <tr>
			    <td colspan="2" style="padding: 0 5px;">
				  Ortsteil <br>
				  <input type="text" style="width: 100%; height: 20px;" value="' . $this->data["hoData"]["fDistrict"] . '">
				</td>
			  </tr>
			</table>
			
			<table>
			  <tr>
			    <td>
				  sowie an und in den darauf befindlichen Gebäuden alle die Vorrichtungen anbringt, die erforderlich sind, 
                  um Zugänge zu seinem öffentlichen Telekommunikationsnetz auf dem betreffenden oder einem 
                  benachbarten Grundstück und in den darauf befindlichen Gebäuden einzurichten, zu prüfen und instand 
                  zu halten. Dieses Recht erstreckt sich auch auf vorinstallierte Hausverkabelungen. Die Inanspruchnahme 
                  des Grundstücks durch Vorrichtungen darf nur zu einer notwendigen und zumutbaren Belastung führen.
				</td>
			  </tr>
			</table>
			<br>';

			$returnValue .= $this->buildFooter();
			$returnValue .= '<div style="page-break-before: always;"></div>';  
			$returnValue .= $this->buildHeader($typ);
			$returnValue .= $this->buildMainContent2();
			$returnValue .= $this->buildFooter();
			  
		  break;
		case 4:
		  $name     = '';
		  $address  = '';
		  $salut    = '';
		  $contact  = '';
		  $bDay     = '';
		  $psTae    = 'keine Angabe';
		  $orderDay = date("d.m.Y");
		  if (array_key_exists("customer", $this->data)) {
		    if ( array_key_exists("salut", $this->data["customer"])
			  && array_key_exists("fName", $this->data["customer"])
			  && array_key_exists("lName", $this->data["customer"])) {
			  $name = $this->data["customer"]["fName"] . ' ' . $this->data["customer"]["lName"];
			  if ($this->data["customer"]["salut"] == 'Herr') {
			    $salut = 'Sehr geehrter ' . $this->data["customer"]["salut"] . ' ' . $name . ',';
			  } else {
			    $salut = 'Sehr geehrte '  . $this->data["customer"]["salut"] . ' ' . $name . ',';
			  }
			}

            if (array_key_exists("birthDay", $this->data["customer"]) {
			  $bDay = date_create($this->data["customer"]["birthDay"]);
			}
			  
			if (array_key_exists("phone", $this->data["customer"])) {
			  $contact = '<tr><td>Telefon</td><td>' . $this->data["customer"]["phone"] . '</td></tr>';
			}
			  
			if (array_key_exists("mobil", $this->data["customer"])) {
			  $contact .= '<tr><td>Mobil</td><td>' . $this->data["customer"]["mobil"] . '</td></tr>';
			}
			  
			if (array_key_exists("mail", $this->data["customer"]) {
			  $contact .= '<tr><td>E-Mail</td><td>' . $this->data["customer"]["mail"] . '</td></tr>';
			}
				
			if (array_key_exists("psTae", $this->data["customer"])) {
			  $psTae = $this->data["customer"]["psTae"];
			}
		  }
		
		  if (array_key_exists("postalAddress", $this->data)) {
		    if ( array_key_exists("street"  , $this->data["postalAddress"])
			  && array_key_exists("hNr"     , $this->data["postalAddress"])
			  && array_key_exists("zipcode" , $this->data["postalAddress"])
			  && array_key_exists("place"   , $this->data["postalAddress"])
			  && array_key_exists("district", $this->data["postalAddress"])) {
			  $address = $name                                   . '<br>'
				       . $this->data["postalAddress"]["street"]  . ' '
				       . $this->data["postalAddress"]["hNr"]     . '<br>'
				       . $this->data["postalAddress"]["zipcode"] . ' '
				       . $this->data["postalAddress"]["place"];
			
			  if ($this->data["postalAddress"]["district"] != "") {
			    $address .= '<br>' . 'Ortsteil: ' . $this->data["postalAddress"]["district"];
			  }
			}
		  }
				
		  $returnValue .= '
		  <table style="width: 100%;">
		    <tr>
			  <td>
			    Project66 IT Service & Design / Brehna.net <br>
                Max-Planck-Str. 2 <br>
                06796 Brehna <br>
			  </td>
			</tr>
			
			<tr>
			  <td>' . $address . '</td>
			</tr>
		  </table>
		  <br><br><br>
		  <table style="width: 100%;">
		    <tr>
			  <td>
			    <b>' . Ihre Auftragsbestellung vom $orderDay . '</b>
			  </td>
			</tr>
		  </table>
		  <br><br><br>
		  <table style="width: 100%;">
		    <tr>
			  <td>' . $salut . '</td>
			</tr>
			
			<tr>
			  <td>vielen Dank für Ihre Bestellung vom ' . $orderDay . '. Wir freuen uns über Ihren Auftrag. Die Details entnehmen Sie bitte der folgenden Übersicht:</td>
			</tr>
		  </table>
		  <hr>
		  <table style="width: 100%;">
		    <tr>
			  <td><b>Anschrift</b></td>
			  
			  <td>' . $address . '</td>
			</tr>
		  </table>
		  <hr>
		  <table style="width: 100%;">
		    <tr>
			  <td><b>Geburtsdatum</b></td>
			  
			  <td>' . $bDay . '</td>
			</tr>
		  </table>
		  <hr>
		  <table>
		    <tr>
			  <td><b>Hauseingang/ Wohnung</b></td>
			</tr>
			
			<tr>
			  <td>' . $psTae . '</td>
			</tr>
		  </table>
		  <hr>
		  <table>' . $contact . '</table>';
			  
	      break;
	  }
		
	  return $returnValue;
	}
	
    private function buildMainContent2(): string {
	  return '
	    <table style="width: 100%;">
		  <tr>
		    <td width="25px">
			  1.
			  <br><br><br>
			  <br><br><br>
			  <br>
			</td>
			
		    <td>
			  Zudem ist der Eigentümer / die Eigentümerin damit einverstanden, dass die nötigen Arbeiten für
              die Glasfaserverlegung bis zur Wohneinheit erforderlich sind, durchgeführt werden können. Diese
              Arbeiten beziehen sich auf die Sicherstellung des Wohnungsanschlusses durch Nutzung bereits
              bestehender Kabeltrassen, stillgelegter Kaminschächte oder ähnlichen bestehenden baulichen
              Vorrichtungen. <br>
			  <i>
			    Falls eine Bestellung der Netzes einen/eine Mieter/Mieterin erfolgt, welcher/welche
                nicht Eigentümer/Eigentümerin des oben aufgeführten Grundstückes ist, willigt der/die 
                Eigentümer / Eigentümerin unter den in Punkt 1 aufgeführten Arbeiten ein.
			  </i>
			</td>
		  </tr>
		  
		  <tr>
		    <td width="25px">
			  2.  <br><br>
			</td>
			
		    <td> <br>
			  Mit Unterzeichnung dieser Grundstückseigentümererklärung erwirbt der Eigentümer / die 
              Eigentümerin keinen Anspruch auf Errichtung des Glasfasernetzes. Die Errichtung unterliegt einer 
              Wirtschaftlichkeitsbetrachtung des Netzbetreibers.
			</td>
		  </tr>
		  
		  <tr>
		    <td width="25px">
			  3.
			  <br><br><br>
			  <br><br><br>
			  <br>
			</td>
			
		    <td> <br>
			  Wenn infolge dieser Vorrichtungen das Grundstück und/oder die darauf befindlichen Gebäude 
              beschädigt werden, ist der Netzbetreiber verpflichtet, die beschädigten Teile des Grundstücks 
              und/oder der Gebäude wieder ordnungsgemäß instand zu setzen. Die vom Netzbetreiber 
              errichteten Vorrichtungen müssen verlegt oder – soweit sie nicht das Grundstück selbst versorgen 
              und eine Verlegung nicht ausreicht – entfernt werden, wenn sie einer veränderten Nutzung des 
              Grundstücks entgegenstehen und ihr Verbleiben an der bisherigen Stelle nicht mehr zumutbar ist. 
              Die Kosten für die Verlegung oder Entfernung trägt der Netzbetreiber. Dies gilt nicht für 
              Vorrichtungen, die ausschließlich das Grundstück versorgen, es sei denn, es sind gleichzeitig 
              Änderungen am Glasfasernetz erforderlich.
			</td>
		  </tr>
		  
		  <tr>
		    <td width="25px"> <br>
			  4.
			</td>
			
		    <td> <br>
			  Die Erklärung gilt auf unbestimmte Zeit und kann nur aus wichtigem Grund zurückgezogen 
              werden.
			</td>
		  </tr>
		  
		  <tr>
		    <td width="25px">
			  5.
			  <br><br><br>
			  <br><br>
			</td>
			
		    <td> <br>
			  Der Eigentümer / die Eigentümerin erklärt sich insbesondere damit einverstanden, dass ihre 
              Kontaktdaten an die des Netzbetreibers bevollmächtigten Unternehmen und ggf. an weitere 
              Subunternehmer weitergegeben, die mit der Errichtung und/oder dem Betrieb der 
              Baumaßnahme betraut werden, um in Ihrem Interesse einerseits eine reibungslose 
              Bauausführung und andererseits einen störungsfreien Betrieb zu ermöglichen. Die betroffenen 
              Unternehmen werden auf die Einhaltung der geltenden Datenschutzbestimmungen (BDSG) 
              verpflichtet.
			</td>
		  </tr>
		</table>
		
		<br><br><br><br>
		
		<table style="width: 100%;">
		  <tr>
		    <td colspan="2">
			  <input type="text" style="width: 100%; border: none; border-bottom: 1px solid black;">
			</td>
		  </tr>
		
		  <tr>
		    <td>
			  <span style="font-size: 10px;">Ort, Datum</span>
			  <br><br>
			</td>
			
			<td>
			  <span style="font-size: 10px;">
			    <table>
				  <tr>
				    <td>
					  <input type="checkbox" id="u1">
					  <br>
					  <input type="checkbox" id="u2">
					</td>
					
					<td>
					  Unterschrift(en) des/der Grundstückseigentümer(s
					  <br><br>
					  Unterschrift der/des Vertreterin/Vertreters einer Grundstücksgemeinschaft
					</td>
				  </tr>
				</table>
			  </span>
		    </td>
		  </tr>
		</table>
		<br><br><br>
		<br><br><br>
		<br><br><br>
		<br>';
	}
	
	private function buildHeader($typ): string {
	  $headerTitle = '';
		
	  switch ($typ) {
		case 1:
		  // SEPA
		  $headerTitle = 'SEPA Lastschriftmandat';
		  break;
		case 2:
		  // Anbieterwechselauftrag
		  $headerTitle = 'Anbieterwechselauftrag von Project66 IT-Systemhaus (Brehna.net)';
		  break;
		case 3:
		  // Gundstückseigentümererklärung
		  $headerTitle = 'Gundstückseigentümererklärung';
		  break;
		case 4:
		  $headerTitle = 'Auftrag Privatkunden';
		  break;
	  }
		
	  $returnValue = '
	    <div class="row puffer">
	      <div class="col"><strong>' . $headerTitle . '</strong></div>
	    </div>';
	  
      if ($typ != 2) {
	    $returnValue .= '<hr>';
	  }

	  return $returnValue;
	}
	  
	private function buildFooter(): string {
	  $returnValue = '<hr>
	    <table style="border: 1px solid black;width: 100%;">
		  <tr style="width=150px;">
		    <td></td>
			
			<td style="font-size: 10px;">
		      Inhaber: Niels Rosenhahn <br>
		      Max-Planck-Straße 2      <br>
		      06796 Sandersdorf-Brehna <br>
		      Ortsteil: Brehna
			</td>
			
			<td style="font-size: 10px;">
		      Telefon: (034954) 524-66 <br>
		      Fax    : (034954) 524-67 <br>
		      Web    : www.brehna.net  <br>
		      E-Mail : info@brehna.net
			</td>
			
			<td style="font-size: 10px;">
		      Technischer Notdienst: <br> (034954) 524-68 <br>
		      Umsatzsteuer-ID      : <br> DE234728145
			</td>
		  </tr>
		</table>';
	    
	  return $returnValue;
	}
	  
	private function getBase64Code($imagePath) {
	  $type = pathinfo($imagePath, PATHINFO_EXTENSION);
	  $fileContent = file_get_contents(__DIR__ . "/anbieterwechsel2.JPG");
	  return 'data:image/' . $type . ';base64,' . base64_encode($fileContent);
	}
  }
?>