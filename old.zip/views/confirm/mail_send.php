<?php
  // https://stackoverflow.com/questions/7814910/how-to-send-an-html-email-using-smtp-in-php
  
  use PHPMailer\PHPMailer\PHPMailer;
  use PHPMailer\PHPMailer\Exception;

  $main = str_replace("/views/confirm", "", __DIR__);
  
  require_once $main . "/plugins/PHPMailer/src/Exception.php";
  require_once $main . "/plugins/PHPMailer/src/PHPMailer.php";
  require_once $main . "/plugins/PHPMailer/src/SMTP.php";

  require_once $main . "/model/technology_queries.php";
  require_once $main . "/model/tariff_queries.php";
  require_once $main . "/model/contract_category_queries.php";

  class MailSend {
	public $data   = array();
	
	private $mailHost   = 'webserver.project66.de';
    private $mailUser   = 'websiteformular@brehna.net';
	private $mailPwd    = 'rnDy946&';
    private $mailPort   = 587;
	  
	private $from       = 'websiteformular@brehna.net';
	private $replyTo    = 'janinakyas@web.de';
	private $cusAddress = 'janinakyas@web.de';
	private $cc         = '';
	private $bcc        = '';
	  
	private $subject    = '';
	private $body       = '';
	
	private $isHtml     = true;
	private $charSet    = 'UTF-8';
	private $encoding   = 'base64';
	  
	private $name       = '';
	private $salut      = '';
	  
    public function __construct($newData) {
	  $this->data   = $newData;
	}
	
	public function sendMail($msgTyp = 1, $attachments = array()): bool {
      $returnValue = true;
	  
      $this->name  = '';
	  $this->salut = '';
	  if ( array_key_exists("customer", $this->data)
		&& array_key_exists("salut"   , $this->data["customer"])
		&& array_key_exists("fName"   , $this->data["customer"])
		&& array_key_exists("lName"   , $this->data["customer"])
		&& array_key_exists("mail"    , $this->data["customer"])) {
	    if ( array_key_exists("company" , $this->data["customer"])
		 &&  $this->data["customer"]["company"] != "") {
		  $this->name  = $this->data["customer"]["company"];
		  $this->salut = 'Sehr geehrte Damen und Herren,';
		} else {
		  $this->name = $this->data["customer"]["salut"] . " " . $this->data["customer"]["fName"] . ", " . $this->data["customer"]["lName"];
			
		  if ($this->data["customer"]["salut"] == 'Herr') {
		    $this->salut = 'Sehr geehrter ' . $this->name . ',';
		  } else {
		    $this->salut = 'Sehr geehrte '  . $this->name . ',';
		  }
		}
		
		$this->cusAddress = $this->data["customer"]["mail"];
	  }
		
	  switch($msgTyp) {
	    case 1:
		  $this->subject = 'Anschluss-Anfrage ' . $this->name;
		  $this->body    = $this->buildConnectionMsgText();
		  $addressMail   = $this->replyTo;
		  break;
		case 2:
		  $this->subject = 'Bestätigung Auftrag Glassfaserhausanschluss vom ' . date("m.d.y");
		  $this->body    = $this->buildFtthMsgText();
		  $addressMail   = $this->cusAddress;
		  break;
		case 3:
		  $this->subject = 'Bestätigung Auftrag vom ' . date("m.d.y");
		  $this->body    = $this->buildContractMsgText();
		  $addressMail   = $this->cusAddress;
		  break;
	  }
		
	  try {
		$phpMailer = new PHPMailer(true);
		  
	    $phpMailer->CharSet = $this->charSet;

		// server settings
		$phpMailer->isSMTP();
		$phpMailer->Host       = $this->mailHost;
		$phpMailer->SMTPAuth   = true;
		$phpMailer->Username   = $this->mailUser;
		$phpMailer->Password   = $this->mailPwd;
		$phpMailer->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
		$phpMailer->port       = $this->mailPort;
		  
	    // recipients
		$phpMailer->setFrom($this->from, 'IT-Systemhaus Project66 / Brehna.net');
		$phpMailer->addReplyTo($this->replyTo, 'Janina Kyas');
		$phpMailer->addAddress($addressMail);
		  
		// content
		$phpMailer->isHTML($this->isHtml);
		$phpMailer->Subject = $this->subject;
		$phpMailer->Body    = $this->body;
		  
		// add attachments
		if (!empty($attachments)) {
		  for ($i = 0; $i < count($attachments["filePaths"]); $i++) {
			$phpMailer->AddAttachment($attachments["filePaths"][$i], $attachments["fileNames"][$i]);
		  }
		}
		  
		$returnValue = $phpMailer->send();
	  } catch (Exception $e) {
	    echo "Message could not be sent. Mailer Error: {$phpMailer->ErrorInfo}";
	  }
		
	  return $returnValue;
	}
	
	private function buildConnectionMsgText(): string {
	  $rateQueries     = new TariffQueries();
      $techKindQueries = new TechnologyQueries();
      $conTypeQueries  = new ContractCategoryQueries();
		
	  $returnValue = '
	    <html>
		  <body style="font-family: \'Barlow\'; font-size: 1rem; line-height: 1.5em;">
			Hallo,
			<br>
			<br>
			Es ist eine neue Anschluss-Anfrage mit den folgenden Details eingegangen:
			<br>
			<br>
			<table style="background-color: #f2f2f2; border-collapse: collapse;">';

      if ( array_key_exists("customer", $this->data)
		&& array_key_exists("salut"   , $this->data["customer"])
		&& array_key_exists("fName"   , $this->data["customer"])
		&& array_key_exists("lName"   , $this->data["customer"])
		&& array_key_exists("company" , $this->data["customer"])
		&& array_key_exists("postalAddress" , $this->data)
		&& array_key_exists("street"   , $this->data["postalAddress"])
		&& array_key_exists("hNr"      , $this->data["postalAddress"])
		&& array_key_exists("zipcode"  , $this->data["postalAddress"])
		&& array_key_exists("place"    , $this->data["postalAddress"])
		&& array_key_exists("district" , $this->data["postalAddress"])
		&& array_key_exists("phone"    , $this->data["customer"])
		&& array_key_exists("mobil"    , $this->data["customer"])
		&& array_key_exists("mail"     , $this->data["customer"])) {
			  
		  $returnValue .= '
			<tr style="border-bottom: 1px solid black; font-size: 12px;">
			  <td style="padding: 15px;">Anschrift</td>
			  <td style="padding: 15px;">';
			  
			if ($this->data["customer"]["company"] != "") {
			  $returnValue .= $this->data["customer"]["company"] . "<br>";
			}
			  
			$returnValue .= $this->data["customer"]["salut"]                                 . "<br>" 
			              . $this->data["customer"]["fName"]        . " " . $this->data["customer"]["lName"]  . "<br>"
						  . $this->data["postalAddress"]["street"]  . " " . $this->data["postalAddress"]["hNr"]    . "<br>"
						  . $this->data["postalAddress"]["zipcode"] . " " . $this->data["postalAddress"]["place"];
							  
			if ($this->data["postalAddress"]["district"] != "") {
			  $returnValue .= "<br>Ortsteil: " . $this->data["postalAddress"]["district"]; 
			}
			  
			$returnValue .= '
			    </td>
			  </tr>
			  <tr style="border-bottom: 1px solid black; font-size: 12px;">
				<td style="padding: 15px;">Kontakt</td>
				<td style="padding: 15px;">
				  Telefon: ' . $this->data["customer"]["phone"] . '<br>
			      Mobil  : ' . $this->data["customer"]["mobil"] . '<br>
				  E-Mail : ' . $this->data["customer"]["mail"]  . '</td>
			  </tr>';				
		  }
			
		  if ( array_key_exists("recall", $this->data)
			&& array_key_exists("isWish", $this->data["recall"])
		    && array_key_exists("termin", $this->data["recall"])) {
			$strRecall = "nein";
			if ($this->data["recall"]["isWish"] == 1) {
			  $strRecall = "ja";
				
			  if ($this->data["recall"]["termin"] != "") {
			    $date       = date_create($this->data["recall"]["termin"]);
			    $strRecall .= ' zum ' . date_format($date, "d.m.Y");
			  }
		    }
				  
			$returnValue .= '<tr style="border-bottom: 1px solid black; font-size: 12px;">
			  <td style="padding: 15px;">Rückruf ist gewünscht</td>
			  <td style="padding: 15px;">' . $strRecall . '</td>
			</tr>';
		  }

          $contractType[0]["name"] = "keine Angabe";
          if (array_key_exists("conKind", $this->data) && $this->data["conKind"] > 0) {
			$contractType = $conTypeQueries->getContractCategoriesById($this->data["conKind"]);
		  }

          $selectedTech[0]["name"] = "keine Angabe";
          if (array_key_exists("selTech", $this->data) && $this->data["selTech"] > 0) {
			$selectedTech = $techKindQueries->getTechKindById($this->data["selTech"]);
		  }

          $conRequestRate[0]["rate"] = "keine Angabe";
          if (array_key_exists("conRequestRate", $this->data) && $this->data["conRequestRate"] > 0) {
			$conRequestRate = $rateQueries->getRateById($this->data["conRequestRate"]);
		  }
			
		  $techCare[0]["name"] = "nicht sicher";
		  if (array_key_exists("techCare", $this->data) && $this->data["techCare"] > 0) {
			$techCare = $techKindQueries->getTechKindById($this->data["techCare"]);
		  }

		  
		
          $returnValue .= '
			<tr style="border-bottom: 1px solid black; font-size: 12px;">
			  <td style="padding: 15px;">Bei dem Anschluss handelt es sich um</td>
			  <td style="padding: 15px;">' . $contractType[0]["name"] . '</td>
			<tr>
			  
			<tr style="border-bottom: 1px solid black; font-size: 12px;">
			  <td style="padding: 15px;">gewünschte Technology</td>
			  <td style="padding: 15px;">' . $selectedTech[0]["name"] . '</td>
			<tr>
			  
			<tr style="border-bottom: 1px solid black; font-size: 12px;">
			  <td style="padding: 15px;">gewünschter Tarif</td>
			  <td style="padding: 15px;">' . $conRequestRate[0]["rate"] . '</td>
			<tr>
			  
			<tr style="border-bottom: 1px solid black; font-size: 12px;">
			  <td style="padding: 15px;">Kunde ist über folgende Technology versorgt</td>
			  <td style="padding: 15px;">' . $techCare[0]["name"] . '</td>
			<tr>';

          $options      = "keine Angabe";
		  $optionsPort  = "";
		  $optionsPhone = "";
          if (array_key_exists("porting", $this->data) && $this->data["porting"] == 1) {
			$optionsPort = "Rufnummernmitnahme";
			$options     = $optionsPort;
		  }
			
		  if (array_key_exists("phone", $this->data) && $this->data["phone"] == 1) {
			$optionsPhone = "Telefonie";
			$options      = $optionsPhone;
		  }
			
		  if ($optionsPort != "" && $optionsPhone != "") {
			$options = $optionsPort . '<br>' . $optionsPhone;	
		  }
			
		  $returnValue .= '
			<tr style="border-bottom: 1px solid black; font-size: 12px;">
			  <td style="padding: 15px;">Otionen</td>
		      <td style="padding: 15px;">' . $options . '</td>
			</tr>';
			
		  $careTermin = "kein Angabe";
		  if (array_key_exists("careTermin", $this->data) && $this->data["careTermin1"] != "") {
			$date        = date_create($this->data["careTermin1"]);
			$careTermin .= ' zum ' . date_format($date, "d.m.Y");
		  }
			
		  $returnValue .= '
			<tr style="border-bottom: 1px solid black; font-size: 12px;">
			  <td style="padding: 15px;">gewünschter Versorgungstermin</td>
			  <td style="padding: 15px;">' . $careTermin . '</td>
			</tr>';		
			
		  if (array_key_exists("message", $this->data)) {
			$returnValue .= '
			  <tr style=" font-size: 12px;">
				<td style="padding: 15px;">Anfrage vom Kunden:</td>
				<td style="padding: 15px;">' . $this->data["message"] . '</td>
			  </tr>'; 
		  }

          $returnValue .= '
			</table>
			<br>
			<br>
			Bitte die Anfrage bearbeiten und dem Kunden bescheid geben.
		    <br>
			<br>
			Vielen Dank.
			<br>
			<br>
			Mit freundlichen Grüßen
		  </body>
		</html>';
			
	  return $returnValue;
	}
	  
    private function buildFtthMsgText(): string {		
	  return '
	    <html>
		  <body style="font-family: \'Barlow\'; font-size: 1rem; line-height: 1.5em;">'
		  . $this->salut . '<br><br>'
		  . 'Vielen Dank für Ihre Bestellung!<br><br>'
		  . 'Wir haben Ihren Auftrag erhalten und werden uns so schnell wie möglich mit Ihnen in 
			Verbindung setzen.<br><br>'
		  . 'Anbei im Anhang erhalten Sie alle wichtigen Dokumente.<br><br>'
		  . 'Bitte senden Sie uns die Unterlagen unterschrieben an die folgende Adresse:<br><br>'
		  . 'Project66 IT Service & Design / Brehna.net<br>'
		  . 'Max-Planck-Str. 2<br>'
		  . '06796 Brehna<br><br>'
		  . 'Bei Fragen, Unklarheiten oder Problemen zu Ihrem Auftrag rufen Sie uns bitte unter der 
			Telefonnummer (034954) 524 66 oder senden Sie eine E-Mail an info@brehna.net.<br><br>'
		  . 'Wir freuen uns auf die Zusammenarbeit!<br><br>'
		  . 'Mit freundlichen Grüßen<br><br>'
		  . 'Project66 IT Service & Design / Brehna.net<br>'
		  . 'Max-Planck-Str. 2<br>'
		  . '06796 Brehna'
          . '</body>
		</html>';
	}
	  
    private function buildContractMsgText(): string {		
	  return '
	    <html>
		  <body style="font-family: \'Barlow\'; font-size: 1rem; line-height: 1.5em;">'
		  . $this->salut . '<br><br>'
		  . 'Vielen Dank für Ihre Bestellung!<br><br>'
		  . 'Wir haben Ihren Auftrag erhalten und werden uns so schnell wie möglich mit Ihnen in 
			Verbindung setzen.<br><br>'
		  . 'Anbei im Anhang erhalten Sie alle wichtigen Dokumente.<br><br>'
		  . 'Bitte senden Sie uns die Unterlagen unterschrieben an die folgende Adresse:<br><br>'
		  . 'Project66 IT Service & Design / Brehna.net<br>'
		  . 'Max-Planck-Str. 2<br>'
		  . '06796 Brehna<br><br>'
		  . 'Bei Fragen, Unklarheiten oder Problemen zu Ihrem Auftrag rufen Sie uns bitte unter der 
			Telefonnummer (034954) 524 66 oder senden Sie eine E-Mail an info@brehna.net.<br><br>'
		  . 'Wir freuen uns auf die Zusammenarbeit!<br><br>'
		  . 'Mit freundlichen Grüßen<br><br>'
		  . 'Project66 IT Service & Design / Brehna.net<br>'
		  . 'Max-Planck-Str. 2<br>'
		  . '06796 Brehna'
          . '</body>
		</html>';
	}
  }
?>