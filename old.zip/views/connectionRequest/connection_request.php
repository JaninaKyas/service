<?php  
  declare(strict_types = 1);

  $dir = str_replace("/connectionRequest", "", __DIR__);

  require __DIR__ . "/forms/customer.php";
  require_once $dir    . "/errorMsg/error_message.php";

  class ConnectionRequest {
	public $templateAttributes = array();
	public $templateValues     = array();
	  
	public function __construct($newTemplateAttributes, $newTemplateValues = array()) {
      $this->templateAttributes = $newTemplateAttributes;
	  $this->templateValues     = $newTemplateValues;
	}
	  
	public function getTemplateStep2(): string {
	  $customer = new Customer($this->templateAttributes, $this->templateValues);
	  $returnValue = $customer->buildCustomerTemplate();
	  return $returnValue;
	}
	  
	public function getRecallTemplate(): string {
	  $errorMsg = new ErrorMessage('Bitte füllen Sie alle Pflichtfelder aus.', false, 'cusErrorRec');
		
	  return $errorMsg->buildErrorDiv2() . '<div id="recallContainer">
	      <div class="row puffer">
		    <div class="col">
			  <span class="fontTitle">Rückruftermin</span>
			</div>
		  </div>
		
		  <div class="row puffer">
		    <div class="col">
			  <label id="recALTitel" class="addressLabel">
			    Ich möchte einen Rückruf um mich telefonisch beraten zu lassen.*
			  </label>
			</div>
			
			<div class="col-2 topPuffer">
			  <input id="reAnswerYes"
			         name="reAnswer"
					 type="radio"
					 onClick="displayRecallTerminMain(1)"> Ja
			</div>
			
			<div class="col-2 topPuffer">
			  <input id="reAnswerNo"
			         name="reAnswer"
					 type="radio"
			         onClick="displayRecallTerminMain(0)"> Nein
			</div>
		  </div>
		  
		  <div class="row puffer">
		    <div class="col">
			  <span id="terminRecallMain">
			    <label class="addressLabel">Angabe Termin für Rückruf*</label>
		        <input type="datetime-local" id="terminRecall" name="terminRecall" class="form-control">
			  </span>
			</div>
		  </div>
		</div>
	  ';
	}
  }
?>