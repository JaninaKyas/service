<?php  
  declare(strict_types = 1);

  $dir = str_replace("connectionRequest", "", __DIR__);
  require_once $dir . "/rates/forms/rate_card.php";

  class ConnectionRequest {
	public $rates    = array();
	public $rateInfo = array();
	  
	public function __construct($newRates, $newRateInfo) {
      $this->rates    = $newRates;
	  $this->rateInfo = $newRateInfo;
	}
	  
	public function buildConnectionRequestRateTemplate(): string {
	  $rateCard     = new RateCard($this->rateInfo[0]);
		
	  $returnValue = '<div class="row puffer left">
	    <div class="col">
		  <strong>Welchen Tarif suchen Sie?</strong>
		</div>
		
		<div class="col">
		  <select id="conRequestRate" name="conRequestRate" onchange="loadRateData(\'conRequestRate\')">';
		  
		if (!empty($this->rates)) {
		  for ($i=0;$i < count($this->rates); $i++) {
		    $returnValue .= '<option value="' . $this->rates[$i]["rateId"] . '">' . $this->rates[$i]["rate"] . '</option>';	
		  }
		}
		
		$returnValue .= '  
		  </select>
		</div>
	  </div>
	  
	  <div class="row puffer left">
	    <div class="col">
		  <div id="conRateInfos">' .  $rateCard->getRateCard(false) . '</div>
		</div>
	  </div>';
	  
	  return $returnValue;
	}
  }
?>