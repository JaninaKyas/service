<?php
  declare(strict_types = 1);

  require_once __DIR__ . "/address.php";

  class Customer {
	public $templateData = array();
	public $values       = array();
	public $techAddress  = array();

    public function __construct($newTemplateData, $newValues = array(), $newTechAddress = array()) {
      $this->templateData = $newTemplateData;
	  $this->values       = $newValues;
	  $this->techAddress  = $newTechAddress;
	}
	  
	public function buildCustomerTemplate(): string {
	  $errMsg = new ErrorMessage('Bitte füllen Sie alle Pflichtfelder aus.', false, 'gfErrMsg');	
	  return $errMsg->buildErrorDiv2()
		. '<div class="fontTitle">Glasfaserhausanschluss</div>'
		. '<div class="customerBlock">'
		. $this->buildDescriptionSection()
		. $this->buildSalutationSection() . '<hr>'
		. $this->buildAddressSection()    . '<hr>'
		. $this->buildContactSection()    . '<hr>'
		. $this->buildTechAddressSection()
		. '</div>';
	}
	  
	protected function buildDescriptionSection(): string {
	  return '<div class="row">
		  <div class="col left">
		    Dieser Auftrag dient zur Herstellung eines Glasfaserhausanschlusses FttH via Mikrorohrsystem. 
			Enthalten ist eine Begehung vor Ort, der erforderliche Tiefbau, das Verlegen des Leerrohrs 
			sowie die Lieferung des Glasfaserkabels.Der Hausanschluss umfasst eine Anschlusslänge von 15m 
			ab Leerrohrtrasse bis zum Hausübergabepunkt (HÜP). Für die Innenverlegung wird ein 20m 
			Glasfaserpatchkabel zur Selbstmontage sowie das Glasfasermodem bereitgestellt (eine 
			Installation kann ebenfalls durch uns erfolgen).
		  </div>
		</div>
	  ';
	}
	  
	protected function buildSalutationSection(): string {		
	  $returnValue = '  
	    <div class="row puffer">
		  <div class="col">
		    <label class="addressLabel">Anrede</label>
		    <select id="'   . $this->templateData["personalData"][0] . '"
			        name="' . $this->templateData["personalData"][0] . '"
			  	    class="form-select selectBox">
			  <option value="Herr" selected>Herr</option>
			  <option value="Frau">Frau</option>
			</select>
		  </div>
		  
		  <div class="col">
		    <label class="addressLabel">Vorname*</label>
		    <input type="text"
			       id="'   . $this->templateData["personalData"][1] . '"
			  	   name="' . $this->templateData["personalData"][1] . '"
				   class="form-control requiredF">
		  </div>

		  <div class="col">
		    <label class="addressLabel">Name*</label>
		    <input type="text"
			       id="'   . $this->templateData["personalData"][2] . '"
				   name="' . $this->templateData["personalData"][2] . '"
				   class="form-control requiredF">
		  </div>
		</div>
		
		<div class="row puffer">
		  <div class="col">
		    <label class="addressLabel">Firma (falls Auftrag als Geschäftskunde)</label>
			<input type="text"
			       class="form-control"
				   id="companyFttH"
				   name="companyFttH">
		  </div>
		</div>';
		
	  return $returnValue;
	}
	  
	protected function buildAddressSection(): string {
	  $address = new Address($this->templateData["postalAddress"], $this->values["postalAddress"]);
	  return $address->buildAddressTemplate();
	}
	  
	protected function buildContactSection(): string {
	  $returnValue = '
	    <div class="row puffer">
		  <div class="col">
		    <label class="addressLabel">Telefon*</label>
		    <input type="text"
			       id="'   . $this->templateData["personalData"][5] . '"
				   name="' . $this->templateData["personalData"][5] . '"
				   class="form-control requiredF">
		  </div>
		  
		  <div class="col">
		    <label class="addressLabel">Mobil*</label>
		    <input type="text"
			       id="'   . $this->templateData["personalData"][6] . '"
				   name="' . $this->templateData["personalData"][6] . '"
				   class="form-control requiredF">
		  </div>
		</div>
		
		<div class="row puffer">
		  <div class="col">
		    <label class="addressLabel">E-Mail*</label>
		    <input type="text"
			       id="'   . $this->templateData["personalData"][4] . '"
				   name="' . $this->templateData["personalData"][4] . '"
				   class="form-control requiredF">
		  </div>
		</div>
	  ';
	  return $returnValue;
	}
	  
	protected function buildTechAddressSection(): string {
	  $address = new Address($this->templateData["connecAddress"], array(), $this->techAddress);
	  return $address->buildTechAddressTemplate();
	}
  }
?>