<?php
  declare(strict_types = 1);

  class GlassFibreSepa {
	public $values    = array();
	public $isWithAGB = false; 
	  
	public function __construct($newValues, $newIsWithAGB = false) {
	  $this->values    = $newValues;
	  $this->isWithAGB = $newIsWithAGB;
	}
	  
	public function buildGlassFibreKontoTemplate($customer, $address): string {
	  $returnValue = '<div class="row puffer left">
          <div class="col">
		    <label class="addressLabel">Zahlweise</label>
		  </div>
		</div>
		
		<div class="row puffer left">
		  <div class="col">
		    <input type ="radio"
			       id   ="sepaFCon1"
				   name ="sepaFCon"
				   value="' . $this->values[0]["id"] . '"
				   onClick="displayNumMenu()"
				   checked> '
		  . $this->values[0]["name"] .
		' </div>
		  
		  <div class="col">
		    <input type="radio"
			       id="sepaFCon2"
				   name="sepaFCon"
				   value="' . $this->values[1]["id"] . '"
				   onClick="displayNumMenu()"> '
		  . $this->values[1]["name"] .	
		 ' </div>
		</div>
		
		<div id="numDurationBox" class="borderBoxSub">
		  <div class="row puffer">
		    <div class="col">
		    <input type ="radio"
			       id   ="sepaFCon3"
				   name ="sepaFCon1"
				   value="' . $this->values[2]["id"] . '"
				   checked> ' . $this->values[2]["name"] . '
			</div>
			
			<div class="col">
		    <input type ="radio"
			       id   ="sepaFCon4"
				   name ="sepaFCon1"
				   value="' . $this->values[3]["id"] . '"> ' . $this->values[3]["name"] . '
			</div>
		  </div>
		</div>
		<br>  
		<div class="alert alert-primary" role="alert">  
		<div class="row puffer left">
		  <div class="col">
		    <i><strong>Achtung!</strong> Einzugsermächtigung für Lastschriftverfahren wird mit folgendem SEPA-Mandat erteilt</i>
		  </div>
		</div>' . $this->buildSepaTemplate($customer, $address) . '</div>';

	  return $returnValue;
	}
	  
	private function buildSepaTemplate($customer, $address): string {
	  $name = $customer["fName"] . ' ' . $customer["lName"];
	  if ($customer["company"] != "") {
	    $name = $customer["company"];
	  }
		
	  $returnValue = '<div id="ftthSepa" class="borderBoxSub">
	    <div class="row puffer left">
		  <div class="col">
		    <strong>SEPA-Basis Lastschriftmandat</strong>
		    <br>
		    Project66 IT Service & Design / Brehna.net
		    <br>
		    Max-Planck-Str. 2, 06796 Brehna
		  </div>
		</div>
		
	    <div class="row puffer left">
		  <div class="col">
		    <strong>Gläubiger-Identifikationsnummer</strong>
		    <br>
		    DE68ZZZ00002002280
		  </div>
		</div>
		
	    <div class="row puffer left">
		  <div class="col">
		    Project66 IT Service & Design / Brehna.net<br>
			Max-Planck-Str. 2<br>
			06796 Brehna
		  </div>
		</div>
		
		<div class="row puffer left">
		  <div class="col">
		    Zahlungspflichtiger*
			<input type="text" class="form-control requiredSepaFtth" id="debatorName" name="debatorName" value="' . $name . '">
		  </div>
		</div>
		
		<div class="row puffer left">
		  <div class="col">
		    Zahlungspflichtige Strasse*
			<input type="text" class="form-control requiredSepaFtth" id="debatorStreet" name="debatorStreet" value="' . $address["street"] . '">
		  </div>
		  
		  <div class="col">
		    Zahlungspflichtige Hausnummer*
			<input type="text" class="form-control requiredSepaFtth" id="debatorHNr" name="debatorHNr" value="' . $address["hNr"] . '">
		  </div>
		</div>
		
		<div class="row puffer left">
		  <div class="col">
		    Zahlungspflichtige Postleitzahl*
			<input type="text" class="form-control requiredSepaFtth" id="debatorPlz" name="debatorPlz" value="' . $address["zipcode"] . '">
		  </div>
		  
		  <div class="col">
		    Zahlungspflichtiger Ort*
			<input type="text" class="form-control requiredSepaFtth" id="debatorPlace" name="debatorPlace" value="' . $address["place"] . '">
		  </div>
		</div>
		
		<div class="row puffer left">
		  <div class="col">
		    Zahlungspflichtige Ortsteil
			<input type="text" class="form-control" id="debatorDistrict" name="debatorDistrict" value="' . $address["district"] . '">
		  </div>
		  
		  <div class="col">
		    Zahlungspflichtiges Land
			<input type="text" class="form-control" id="debatorCountry" name="debatorCountry" value="Deutschland">
		  </div>
		</div>
		
		<div class="row puffer left">
		  <div class="col">
		    Zahlungspflichtige IBAN*
			<input type="text" class="form-control requiredSepaFtth" id="debatorIban" name="debatorIban">
		  </div>
		  
		  <div class="col">
		    Zahlungspflichtige SWIFT BIC*
			<input type="text" class="form-control requiredSepaFtth" id="debatorBic" name="debatorBic">
		  </div>
		</div>
	  </div>
	  
	  <div class="row puffer left">
		<div class="col">
		  Ich ermächtige (Wir ermächtigen) Project66 IT-Service & Design / Brehna.net, Zahlungen
		  von meinem (unseren) Konto mittels Lastschrift einzuziehen. Zugleich weise ich mein
		  (weisen wir unser) Kreditinstitut an, die von Project66 auf mein (unsere) Konto 
		  gezogenen Lastschriften einzulösen.
		</div>
	  </div>
	  
	  <div class="alert alert-info" role="alert">		
	    <div class="row puffer left">
		  <div class="col-sm-2">
            <strong>Hinweise:</strong>
		  </div>
		  
		  <div class="col">
		    Ich kann / Wir können innerhalb von acht Wochen beginnend mit dem Belastungsdatum, die
		    Erstattung des belasteten Betrages verlangen. Es gelten dabei die mit meinem / unserem 
			Kreditinstitut vereinbarten Bedingungen.
			<br><br>
			Bitte lassen Sie sich den Eingang des SEPA-Mandates von Ihrer Bank bestätigen.
		  </div>
		</div>
	  </div>';

	  if ($this->isWithAGB) {
	    $returnValue .= $this->buildAGBTemplate(); 
	  }
		
	  return $returnValue;
	}
	  
	public function buildAGBTemplate(): string {
	  return '
	    <div id="ftthErrAgb" class="blockDiv">
          <div class="row">
	        <div class="col">
	          <div class="alert alert-danger" role="alert">
		        <img id="errorImg"
			         src="https://neu.brehna.net/auftrag/public/images/error-5.png"
					 alt="errorMsg">
		        <span>
				  Eine weitere Bearbeitung des Auftrages ist nur mit Zustimmung des Datenschutzes und der 
				  AGB möglich. Bitte stimmen Sie denm Datenschutz und den AGB zu.
				</span>
	          </div>
	        </div>
          </div>
        </div>
	  
	    <div class="row puffer left">
          <div class="col">
		    <label class="addressLabel">Widerruf</label>
		  </div>
		</div>
		
		<div class="row puffer left">
		  <div class="col">
		    Sie haben das Recht, binnen vierzehn Tagen ohne Angabe von Gründen diesen Vertrag zu 
			widerrufen. Die Widerrufsfrist beträgt vierzehn Tage ab dem Tag des Vertragsabschlusses. Um 
			Ihr Widerrufsrecht auszuüben, müssen Sie uns mittels einer eindeutigen Erklärung (z. B. ein  
			mit der Post versandter Brief, Telefax oder E-Mail) über Ihren Entschluss, diesen Vertrag zu 
			widerrufen, informieren. Dies ist zu richten an Brehna.net, Max-Planck-Straße 2, 06796 
			Brehna. Zur Wahrung der Widerrufsfrist reicht es aus, dass Sie die Mitteilung über die 
			Ausübung des Widerrufsrechts vor Ablauf der Widerrufsfrist absenden.
		  </div>
		</div>
		<hr>
		
		<div class="row puffer left">
		  <div class="col">
		    <input type="checkbox" id="checkProcessData" name="checkProcessData" class="requiredSepaFttH"> 
			<strong>Ich stimme der Weiterverarbeitung meiner Daten zu.</strong>
			<span class="smFont">
			  (<a href="https://www.brehna.net/datenschutz">www.brehna.net/datenschutz</a>)
			</span>
		  </div>
		</div>
		
		<div class="row puffer left">
		  <div class="col">
		    <input type="checkbox" id="checkAGB" name="checkAGB" class="requiredSepaFttH"> 
			<strong>Ich habe die AGB gelesen und akzeptiere die AGB von Brehna.net.</strong>
			<span class="smFont">
			  (<a href="https://brehna.net/agb">www.brehna.net/agb</a>)
			</span>
		  </div>
		</div>';
	}
  }
?>