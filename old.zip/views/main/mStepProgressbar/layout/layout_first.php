<?php
  $mainPath = str_replace("views/main/mStepProgressbar/layout", "", __DIR__);
?>

  <div id="multi-step-form-container">
    <ul class="form-stepper form-stepper-horizontal text-center mx-auto pl-0">
      <li class="form-stepper-active text-center form-stepper-list" step="1">
        <a class="mx-2">
          <span class="form-stepper-circle">
            <span>1</span>
          </span>
          <div class="label">Verfügbarkeit</div>
        </a>
      </li>

      <li class="form-stepper-unfinished text-center form-stepper-list" step="2">
        <a class="mx-2">
          <span class="form-stepper-circle text-muted">
            <span>2</span>
          </span>
          <div class="label text-muted">
			<span id="step2Lable">Ergebnis</span>
		  </div>
        </a>
      </li>
		
      <li class="form-stepper-unfinished text-center form-stepper-list" step="3">
        <a class="mx-2">
          <span class="form-stepper-circle text-muted">
            <span>3</span>
          </span>
          <div class="label text-muted">
			<span id="step3Lable">Kundendaten</span>
		  </div>
        </a>
      </li>
		
      <li class="form-stepper-unfinished text-center form-stepper-list" step="4">
        <a class="mx-2">
          <span class="form-stepper-circle text-muted">
            <span>4</span>
          </span>
          <div class="label text-muted">
			<span id="step4Lable">Optionen</span>
		  </div>
        </a>
      </li>
	  
      <li class="form-stepper-unfinished text-center form-stepper-list" step="5">
        <a class="mx-2">
          <span class="form-stepper-circle text-muted">
            <span>5</span>
          </span>
          <div class="label text-muted">
			<span id="step5Lable">Konto</span>
		  </div>
        </a>
      </li>
	  
      <li class="form-stepper-unfinished text-center form-stepper-list" step="6">
        <a class="mx-2">
          <span class="form-stepper-circle text-muted">
            <span>6</span>
          </span>
          <div class="label text-muted">
			<span id="step6Lable">AGB</span>
		  </div>
        </a>
      </li>
	  
      <li class="form-stepper-unfinished text-center form-stepper-list" step="7">
        <a class="mx-2">
          <span class="form-stepper-circle text-muted">
            <span>7</span>
          </span>
          <div class="label text-muted">
			<span id="step7Lable">Überblick</span>
		  </div>
        </a>
      </li>
		
      <li class="form-stepper-unfinished text-center form-stepper-list" step="7">
        <a class="mx-2">
          <span class="form-stepper-circle text-muted">
            <span>8</span>
          </span>
          <div class="label text-muted">
			<span id="step8Lable">Bestätigung</span>
		  </div>
        </a>
      </li>
    </ul>


    <form id="userAccountSetupForm" name="userAccountSetupForm" enctype="multipart/form-data" 
	      method="POST" class="templateBox">
      <section id="step-1" class="form-step">
        <div class="mt-3">
		  <?php require $mainPath . "views/internetAvailability/availability.php"; ?>
		</div>
        <div class="mt-3">
          <button class="button btn-navigate-form-step addressButton"
				  type="button" 
				  step_number="2"
				  step_direction="1">Prüfen</button>
        </div>
      </section>

      <section id="step-2" class="form-step d-none templateBox">
		<div class="mt-3"><div id="ratesResult"></div></div>
		<div id="step2BtnMenu">
          <div class="row mt-3">
	        <div class="col">
		      <button id="backBtnStep2"
					  class="button btn-navigate-form-step addressButton"
				      type="button"
					  step_number="1"
					  step_direction="-1">
			    <span id="btnLable1">Zurück</span>
		      </button>
		    </div>
            <div class="col">
              <button id="disForward"
				      class="button btn-navigate-form-step addressButton"
				      type="button"
				      step_number="3"
					  btn_value="2"
					  step_direction="1">
		          <span id="btnLable2">Weiter</span>
		      </button>
		    </div>
          </div>			
		</div>
		<div id="altButtonMenu"></div>
      </section>
		
      <section id="step-3" class="form-step d-none templateBox">
		<div class="mt-3"><div id="step3Result"></div></div>
		<div class="row mt-3">
		  <div class="col">
		    <button class="button btn-navigate-form-step addressButton"
				    type="button"
					step_number="2"
					step_direction="-1">
			  <span>Zurück</span>
			</button>
		  </div>
		  <div class="col">  
		    <button class="button btn-navigate-form-step addressButton"
			  	    type="button"
					step_number="4"
					step_direction="1">
			  <span>Weiter</span>
			</button>
		  </div>
		</div>
	  </section>
		
      <section id="step-4" class="form-step d-none templateBox">
        <div class="mt-3"><div id="step4Result"></div></div>
		<div id="step4ButtonMain">
		  <div class="row mt-3">
		    <div class="col">
		      <button class="button btn-navigate-form-step addressButton"
				      type="button"
					  step_number="3"
					  step_direction="-1">
			    <span>Zurück</span>
			  </button>
		    </div>
		    <div class="col">  
		      <button class="button btn-navigate-form-step addressButton"
			  	      type="button"
					  step_number="5"
					  step_direction="1">
			    <span>Weiter</span>
			  </button>
		    </div>
		  </div>
		</div>
	  </section>
	  
      <section id="step-5" class="form-step d-none templateBox">
        <div class="mt-3"><div id="step5Result"></div></div>
		<div id="step5ButtonMain">
		  <div class="row mt-3">
		    <div class="col">
		      <button class="button btn-navigate-form-step addressButton"
				      type="button"
					  step_number="4"
					  step_direction="-1">
			    <span>Zurück</span>
			  </button>
		    </div>
		    <div class="col">  
		      <button class="button btn-navigate-form-step addressButton"
			  	      type="button"
					  step_number="6"
					  step_direction="1">
			    <span>Weiter</span>
			  </button>
		    </div>
		  </div>
		</div>
	  </section>
	  
      <section id="step-6" class="form-step d-none templateBox">
        <div class="mt-3"><div id="step6Result"></div></div>
		<div id="step5ButtonMain">
		  <div class="row mt-3">
		    <div class="col">
		      <button class="button btn-navigate-form-step addressButton"
				      type="button"
					  step_number="5"
					  step_direction="-1">
			    <span>Zurück</span>
			  </button>
		    </div>
		    <div class="col">  
		      <button class="button btn-navigate-form-step addressButton"
			  	      type="button"
					  step_number="7"
					  step_direction="1">
			    <span>Weiter</span>
			  </button>
		    </div>
		  </div>
		</div>
	  </section>
	  
      <section id="step-7" class="form-step d-none templateBox">
        <div class="mt-3"><div id="step7Result"></div></div>
		<div id="step5ButtonMain">
		  <div class="row mt-3">
		    <div class="col">
		      <button class="button btn-navigate-form-step addressButton"
				      type="button"
					  step_number="6"
					  step_direction="-1">
			    <span>Zurück</span>
			  </button>
		    </div>
		    <div class="col">  
		      <button class="button btn-navigate-form-step addressButton"
			  	      type="button"
					  step_number="8"
					  step_direction="1">
			    <span>Absenden</span>
			  </button>
		    </div>
		  </div>
		</div>
	  </section>
		
      <section id="step-8" class="form-step d-none templateBox">
        <div class="mt-3"><div id="step8Result"></div></div>
		<div id="step5ButtonMain">
		  <div class="row mt-3">
		    <!--div class="col">
		      <button class="button btn-navigate-form-step addressButton"
				      type="button"
					  step_number="7"
					  step_direction="11">
			    <span>Neue Verfügbarkeit prüfen!</span>
			  </button>
		    </div>
		    <div class="col">  
		      <button class="button btn-navigate-form-step addressButton"
			  	      type="button"
					  step_number="-1"
					  step_direction="1">
			    <span>Absenden</span>
			  </button>
		    </div-->
		  </div>
		</div>
	  </section>
    </form>
  </div>