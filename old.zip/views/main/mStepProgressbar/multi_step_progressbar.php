<?php
  declare(strict_types = 1);

  class MultiStepProgressbar {
    public $layoutKind = 1;
	  
	public function __construct($newLayoutKind = 1) {
	  $this->layoutKind = $newLayoutKind;
	}
	  
	public function loadLayout() {
	  if ($this->layoutKind == 1) {
	    require_once __DIR__ . "/layout/layout_first.php";
	  }
	}
  }
?>