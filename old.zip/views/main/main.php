<?php 
  require __DIR__ . "/mStepProgressbar/multi_step_progressbar.php";
  $mspBar = new MultiStepProgressbar(1);
  $mspBar->loadLayout();
?>
