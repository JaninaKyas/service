          <a class="screen-reader-text skip-link" href="#content">Zum Inhalt springen</a>
    <div id="tc-sn" class="tc-sn side-nav__container d-none d-lg-block" >
    <nav class="tc-sn side-nav__nav" >
      <div class="tc-sn-inner">
        <div class="hamburger-toggler__container " >
  <button class="ham-toggler-menu czr-collapsed" data-toggle="sidenav" aria-expanded="false"><span class="ham__toggler-span-wrapper"><span class="line line-1"></span><span class="line line-2"></span><span class="line line-3"></span></span><span class="screen-reader-text">Menü</span></button>
</div>
<div class="nav__menu-wrapper side-nav__menu-wrapper" >
<ul id="main-menu" class="side-nav__menu side vertical-nav nav__menu flex-column nav"><li id="menu-item-116" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-116"><a href="https://neu.brehna.net/news/" class="nav__link"><span class="nav__title">News</span></a></li>
<li id="menu-item-70" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-70"><a href="https://neu.brehna.net/versorgungsgebiete/" class="nav__link"><span class="nav__title">Versorgungsgebiete</span></a></li>
<li id="menu-item-65" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-65"><a href="https://neu.brehna.net/privatkunden/" class="nav__link"><span class="nav__title">Privatkunden</span></a></li>
<li id="menu-item-59" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-59"><a href="https://neu.brehna.net/geschaeftskunden/" class="nav__link"><span class="nav__title">Geschäftskunden</span></a></li>
<li id="menu-item-71" class="menu-item menu-item-type-custom menu-item-object-custom current-menu-ancestor current-menu-parent menu-item-has-children czr-dropdown current-active menu-item-71"><a href="#" class="nav__link"><span class="nav__title">Service</span></a>
<ul class="dropdown-menu czr-dropdown-menu">
	<li id="menu-item-74" class="menu-item menu-item-type-post_type menu-item-object-page dropdown-item menu-item-74"><a href="https://neu.brehna.net/anschluss-anfrage/" class="nav__link"><span class="nav__title">Anschluss – Anfrage</span></a></li>
	<li id="menu-item-67" class="menu-item menu-item-type-post_type menu-item-object-page dropdown-item menu-item-67"><a href="https://neu.brehna.net/support-anfrage/" class="nav__link"><span class="nav__title">Support – Anfrage</span></a></li>
	<li id="menu-item-56" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-43 current_page_item dropdown-item current-active menu-item-56"><a href="https://neu.brehna.net/dokumente/" aria-current="page" class="nav__link"><span class="nav__title">Dokumente</span></a></li>
</ul>
</li>
<li id="menu-item-207" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-207"><a href="https://neu.brehna.net/kontakt/" class="nav__link"><span class="nav__title">Kontakt</span></a></li>
<li id="menu-item-68" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children czr-dropdown menu-item-68"><a href="https://neu.brehna.net/ueber-uns/" class="nav__link"><span class="nav__title">Über Uns</span></a>
<ul class="dropdown-menu czr-dropdown-menu">
	<li id="menu-item-60" class="menu-item menu-item-type-post_type menu-item-object-page dropdown-item menu-item-60"><a href="https://neu.brehna.net/geschichte-entstehung/" class="nav__link"><span class="nav__title">Geschichte &#038; Entstehung</span></a></li>
	<li id="menu-item-64" class="menu-item menu-item-type-post_type menu-item-object-page dropdown-item menu-item-64"><a href="https://neu.brehna.net/partner/" class="nav__link"><span class="nav__title">Partner</span></a></li>
</ul>
</li>
</ul></div>      </div><!-- /.tc-sn-inner  -->
    </nav>
</div>