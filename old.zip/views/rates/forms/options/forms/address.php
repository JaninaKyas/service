<?php
  declare(strict_types = 1);

  class Address {
	public $templateData = array();
	public $values       = array();
	public $address      = array();

    public function __construct($newTemplateData, $newValues = array(), $newAddress) {
      $this->templateData = $newTemplateData;
	  $this->values       = $newValues;
	  $this->address      = $newAddress;
	}
	  
	public function buildAddressTemplate(): string {		
	  return '
	    <div class="row puffer left">
		  <div class="col">
		    Strasse*
		    <input type="text"
			       id="'   . $this->templateData[2] . '"
				   name="' . $this->templateData[2] . '"
				   value="' . $this->address["street"] . '">
		  </div>

		  <div class="col">
		    Hausnummer*
		    <input type="text"
			       id="'   . $this->templateData[3] . '"
				   name="' . $this->templateData[3] . '"
				   value="' . $this->address["hNr"] . '">
		  </div>
		</div>
		
	    <div class="row puffer left">
		  <div class="col">
		    PLZ*
		    <input type="text"
			       id="'   . $this->templateData[4] . '"
				   name="' . $this->templateData[4] . '"
				   value="' . $this->address["zipcode"] . '">
		  </div>

		  <div class="col">
		    Ort*
		    <input type="text"
			       id="'   . $this->templateData[5] . '"
				   name="' . $this->templateData[5] . '"
				   value="' . $this->address["place"] . '">
		  </div>
		</div>
	  ';
	}
  }
?>