<?php
  declare(strict_types = 1);

  class RateKonto {
    public $contractDuration = array();
	public $numerically      = array();
	public $customer         = array();
	public $address          = array();
	
	public function __construct($newContractDuration, $newnumerically, $newCustomer, $newAddress) {
	  $this->contractDuration = $newContractDuration;
	  $this->numerically      = $newnumerically;
	  $this->customer         = $newCustomer;
	  $this->address          = $newAddress;
	}
	  
	public function buildRatesKontoTemplate(): string {
	  return $this->buildContractInfoTemplate() . '<hr>' . $this->buildNumericallyTemplate();
	}
	  
	private function buildContractInfoTemplate(): string {
	  return '
	    <div class="row puffer left">
          <div class="col">
		    <strong>gewünschter Vertrags- und Leistungsbeginn</strong>
		    <input type="date" class="form-control" id="contractBegin" name="contractBegin">
		  </div>
		</div>
		<hr>
		
		<div class="row puffer">
          <div class="col">
		    <label class="addressLabel">Mindestvertragsdauer</label>
		  </div>
        </div>
		
		<div class="row puffer">
		  <div class="col">
		    <input type ="radio"
			       id   ="dur12Month"
				   name ="durMonth"
				   value="' . $this->contractDuration[0]["id"] . '"
				   checked>
			<span>' . $this->contractDuration[0]["duration"] . ' Monate</span>
		  </div>
		  
		  <div class="col">
		    <input type ="radio"
			       id   ="dur24Month"
				   name ="durMonth"
				   value="' . $this->contractDuration[1]["id"] . '">
			<span>' . $this->contractDuration[1]["duration"] . ' Monate</span>
			<span class="smFont">' . $this->contractDuration[1]["term_option"] . '</span>
		  </div>
		</div>';
	}

	private function buildNumericallyTemplate(): string {
	  return '
	    <div class="row puffer left">
          <div class="col">
		    <label class="addressLabel">Zahlweise</label>
		  </div>
		</div>
		
		<div class="row puffer left">
		  <div class="col">
		    <input type ="checkbox"
			       class="form-check-input"
				   id   ="numAddPost"
				   name ="numAddPost"
				   value="' . $this->numerically[0]["id"] . '">
			<span>' . $this->numerically[0]["name"] . '</span>
		  </div>
		  
		  <div class="col price">
		  <span>'
		      . number_format(floatval($this->numerically[0]['price']), 2, ',', ' ')
		      . ' € pro Monat</span>
		  </div>
		</div>
		
		<div class="alert alert-primary" role="alert">
		  <div class="row puffer left">
		  <div class="col">
		    <i><strong>Achtung!</strong> Einzugsermächtigung für Lastschriftverfahren wird mit folgendem SEPA-Mandat erteilt</i>
		  </div>
		</div>' . $this->buildSepaFormTemplate() . '</div>';
	}
	  
	private function buildSepaFormTemplate(): string {		
	  $returnValue = '<div id="rateSepa" class="borderBoxSub">
	    <div class="row puffer left">
		  <div class="col">
		    <strong>SEPA-Basis Lastschriftmandat</strong>
		    <br>
		    Project66 IT Service & Design / Brehna.net
		    <br>
		    Max-Planck-Str. 2, 06796 Brehna
		  </div>
		</div>
		
	    <div class="row puffer left">
		  <div class="col">
		    <strong>Gläubiger-Identifikationsnummer</strong>
		    <br>
		    DE68ZZZ00002002280
		  </div>
		</div>
		
	    <div class="row puffer left">
		  <div class="col">
		    Project66 IT Service & Design / Brehna.net<br>
			Max-Planck-Str. 2<br>
			06796 Brehna
		  </div>
		</div>
		
		<div class="row puffer left">
		  <div class="col">
		    Zahlungspflichtiger*
			<input type="text" class="form-control requiredSepaPK" id="debatorName" name="debatorName" value="' . $this->customer["fName"] . ' ' . $this->customer["lName"] . '">
		  </div>
		</div>
		
		<div class="row puffer left">
		  <div class="col">
		    Zahlungspflichtige Strasse*
			<input type="text" class="form-control requiredSepaPK" id="debatorStreet" name="debatorStreet" value="' . $this->address["street"] . '">
		  </div>
		  
		  <div class="col">
		    Zahlungspflichtige Hausnummer*
			<input type="text" class="form-control requiredSepaPK" id="debatorHNr" name="debatorHNr" value="' . $this->address["hNr"] . '">
		  </div>
		</div>
		
		<div class="row puffer left">
		  <div class="col">
		    Zahlungspflichtige Postleitzahl*
			<input type="text" class="form-control requiredSepaPK" id="debatorPlz" name="debatorPlz" value="' . $this->address["zipcode"] . '">
		  </div>
		  
		  <div class="col">
		    Zahlungspflichtiger Ort*
			<input type="text" class="form-control requiredSepaPK" id="debatorPlace" name="debatorPlace" value="' . $this->address["place"] . '">
		  </div>
		</div>
		
		<div class="row puffer left">
		  <div class="col">
		    Zahlungspflichtige Ortsteil
			<input type="text" class="form-control" id="debatorDistrict" name="debatorDistrict" value="' . $this->address["district"] . '">
		  </div>
		  
		  <div class="col">
		    Zahlungspflichtiges Land
			<input type="text" class="form-control" id="debatorCountry" name="debatorCountry" value="Deutschland">
		  </div>
		</div>
		
		<div class="row puffer left">
		  <div class="col">
		    Zahlungspflichtige IBAN*
			<input type="text" class="form-control requiredSepaPK" id="debatorIban" name="debatorIban">
		  </div>
		  
		  <div class="col">
		    Zahlungspflichtige SWIFT BIC*
			<input type="text" class="form-control requiredSepaPK" id="debatorBic" name="debatorBic">
		  </div>
		</div>
	  </div>
	  
	  <div class="row puffer left">
		<div class="col">
		  Ich ermächtige (Wir ermächtigen) Project66 IT-Service & Design / Brehna.net, Zahlungen
		  von meinem (unseren) Konto mittels Lastschrift einzuziehen. Zugleich weise ich mein
		  (weisen wir unser) Kreditinstitut an, die von Project66 auf mein (unsere) Konto 
		  gezogenen Lastschriften einzulösen.
		</div>
	  </div>
	  
	  <div class="alert alert-info" role="alert">		
	    <div class="row puffer left">
		  <div class="col-sm-2">
            <strong>Hinweise:</strong>
		  </div>
		  
		  <div class="col">
		    Ich kann / Wir können innerhalb von acht Wochen beginnend mit dem Belastungsdatum, die
		    Erstattung des belasteten Betrages verlangen. Es gelten dabei die mit meinem / unserem 
			Kreditinstitut vereinbarten Bedingungen.
			<br><br>
			Bitte lassen Sie sich den Eingang des SEPA-Mandates von Ihrer Bank bestätigen.
		  </div>
		</div>
	  </div>';
		
	  return $returnValue;
	}
	  
    public function buildAGBTemplate(): string {
	  return '
	    <div id="pkErrAgb" class="blockDiv">
          <div class="row">
	        <div class="col">
	          <div class="alert alert-danger" role="alert">
		        <img id="errorImg"
			         src="https://neu.brehna.net/auftrag/public/images/error-5.png"
					 alt="errorMsg">
		        <span>
				  Eine weitere Bearbeitung des Auftrages ist nur mit Zustimmung des Datenschutzes und der 
				  AGB möglich. Bitte stimmen Sie denm Datenschutz und den AGB zu.
				</span>
	          </div>
	        </div>
          </div>
        </div>
	  
	    <div class="row puffer left">
          <div class="col">
		    <strong>AGB</strong>
			<br>
			<span class="smFont">
			  Die aktuellen AGB haben vorgelegen, Wurden gelesen und akzeptiert, und sind jederzeit in 
			  Druckform in den Büroräumen in der Max-Planck-Str. 2, 06796 Brehna einsehbar.
			</span>
			<br><br>
			<span class="smFont"><strong>Alle Preise inkl. der aktuell gültigen MwSt.</strong></span>
		  </div>
		  
		  <div class="col">
		    <strong>Vertragsbedingung</strong>
			<br>
			<span class="smFont">
			  Der Vertragbeginn wird rechtswirksam mit Datum des Netzanschlusses, unabhängig vom Datum 
			  der getätigten Unterschrift auf dem Vertrag. Der Vertrag verlängert sich nach Ablauf der 
			  Mindestvertragsdauer auf unbestimmte Zeit, wenn er nicht mit einer Frist von vier Wochen 
			  zum Ende eines Monats gekündigt wird. Sollte es aus technischen Gründen nicht möglich sein 
			  Sie anzuschalten, erhalten Sie eine Mitteilung, sobald die Anschaltung erfolgen kann.
			</span>
		  </div>
		  
		  <div class="col">
		    <strong>Widerruf</strong>
			<br>
			<span class="smFont">
			  Sie können Ihre Vertragserklärung innerhalb von <strong>zwei</strong> Wochen nach Ihrer 
			  Unterzeichnung ohne Angabe von Gründen in Textform (z.B. Brief, Fax) widerrufen. Zur 
			  Wahrung der Frist genügt der rechtzeitige Eingang des schriftlichen Widerrufs an die Firma 
			  Brehna.net, Max-Planck-Str. 2, 06796 Brehna.
			</span>
		  </div>
		</div>
		<hr>
		
		<div class="row puffer left">
		  <div class="col">
		    <input type="checkbox" id="checkProcessData" name="checkProcessData" class="requiredSepaPK"> 
			<strong>Ich stimme der Weiterverarbeitung meiner Daten zu.</strong>
			<span class="smFont">
			  (<a href="https://www.brehna.net/datenschutz">www.brehna.net/datenschutz</a>)
			</span>
		  </div>
		</div>
		
		<div class="row puffer left">
		  <div class="col">
		    <input type="checkbox" id="checkAGB" name="checkAGB" class="requiredSepaPK"> 
			<strong>Ich habe die AGB gelesen und akzeptiere die AGB von Brehna.net.</strong>
			<span class="smFont">
			  (<a href="https://brehna.net/agb">www.brehna.net/agb</a>)
			</span>
		  </div>
		</div>';
	}
  }
?>