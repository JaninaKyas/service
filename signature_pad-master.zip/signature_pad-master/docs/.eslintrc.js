module.exports = {
  globals: {
    SignaturePad: false
  }
};
